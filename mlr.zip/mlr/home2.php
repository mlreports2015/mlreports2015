<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>mlReports Home</title>

<style>

a.li:link {
	color:#FFF;
	position:relative;
	left:32px;
	text-decoration:none;
	color: #FFF;
}

a.li:visited {
	color:#FFF;
	position:relative;
	left:32px;
	text-decoration:none;
	color: #FFF;
}

a.li:hover {
	color: #000;
}

a.li:active {
	color: #000;
}


a.l:link {
	color:#FFF;
	text-decoration:none;
	color: #FFF;
}

a.l:visited {
	color:#FFF;
	text-decoration:none;
	color: #FFF;
}

a.l:hover {
	color: #000;
}

a.l:active {
	color: #FF0000;
}


li
{
	font-size:16px;
	font-weight:200;
}

</style>

<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>


<script type="text/javascript" language="javascript">

//alert(navigator.appName);
//alert(navigator.appVersion);

var BrowserDetect = {
	init: function () {
		this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
		this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "an unknown version";
		this.OS = this.searchString(this.dataOS) || "an unknown OS";
	},
	searchString: function (data) {
		for (var i=0;i<data.length;i++)	{
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
	},
	searchVersion: function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
	},
	dataBrowser: [
		{
			string: navigator.userAgent,
			subString: "Chrome",
			identity: "Chrome"
		},
		{ 	string: navigator.userAgent,
			subString: "OmniWeb",
			versionSearch: "OmniWeb/",
			identity: "OmniWeb"
		},
		{
			string: navigator.vendor,
			subString: "Apple",
			identity: "Safari",
			versionSearch: "Version"
		},
		{
			prop: window.opera,
			identity: "Opera"
		},
		{
			string: navigator.vendor,
			subString: "iCab",
			identity: "iCab"
		},
		{
			string: navigator.vendor,
			subString: "KDE",
			identity: "Konqueror"
		},
		{
			string: navigator.userAgent,
			subString: "Firefox",
			identity: "Firefox"
		},
		{
			string: navigator.vendor,
			subString: "Camino",
			identity: "Camino"
		},
		{		// for newer Netscapes (6+)
			string: navigator.userAgent,
			subString: "Netscape",
			identity: "Netscape"
		},
		{
			string: navigator.userAgent,
			subString: "MSIE",
			identity: "Explorer",
			versionSearch: "MSIE"
		},
		{
			string: navigator.userAgent,
			subString: "Gecko",
			identity: "Mozilla",
			versionSearch: "rv"
		},
		{ 		// for older Netscapes (4-)
			string: navigator.userAgent,
			subString: "Mozilla",
			identity: "Netscape",
			versionSearch: "Mozilla"
		}
	],
	dataOS : [
		{
			string: navigator.platform,
			subString: "Win",
			identity: "Windows"
		},
		{
			string: navigator.platform,
			subString: "Mac",
			identity: "Mac"
		},
		{
			   string: navigator.userAgent,
			   subString: "iPhone",
			   identity: "iPhone/iPod"
	    },
		{
			string: navigator.platform,
			subString: "Linux",
			identity: "Linux"
		}
	]

};
BrowserDetect.init();

</script>

<script>

function browserChk()
{
if (BrowserDetect.version==7 && BrowserDetect.browser=='Explorer')
{
	document.getElementById('bodd').style.height='15px';
	document.getElementById('cont').style.top='-30px';
	document.getElementById('cont').style.left='100px';
	document.getElementById('cont2').style.top='-160px';
	document.getElementById('footy').style.top='-50px';
	
}
}

</script>


</head>


<body style="margin-top:0px;" topmargin="0" marginheight="0" onLoad="MM_preloadImages('image/aboutH.png','image/serviceH.png','image/supportH.png','image/contactH.png'); browserChk();">

<div id="bodd" style="height:0px; width:100%;"></div>

<div align="center" style="position:relative; top:-15px;">
<div align="left" style="width:1024px; background-color:#FFF; ">

<div id="logo" style="width:383px;height:177px; float:left;">
<img src="image/Logo.png" />
</div>

<div id="redRound" style="position:relative; float:right; width:431px; height:59; background-image:url(image/redCurve.png); color:#fff;">
<table>
<tr>
<td>
<a class="li" href="mlr/index.html">Login</a>
</td>
<td width="90" align="right">
<a class="li" href="mlr/register.html">Register</a>
</td>
<td width='350' align="right">
Tel : 0161 839 3703
</td>
</tr>
</table>
</div>
<p>&nbsp;</p>

<div style="position:relative; left:-30px; top:-100px; z-index:2; vertical-align:middle; float:right;">

<table style="vertical-align:middle;">
<tr>
<td>
<img src="image/mlrfe_16.png" width="124" height="44" />
</td>

<td>
<a href="about.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image5','','image/aboutH.png',1)">
<img src="image/about.png" name="Image5" width="129" height="34" border="0" id="Image5" /></a>
</td>

<td>
<a href="service.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image6','','image/serviceH.png',1)"><img src="image/service.png" name="Image6" width="114" height="34" border="0" id="Image6" /></a>
</td>

<td>
<a href="support.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image7','','image/supportH.png',1)"><img src="image/support.png" name="Image7" width="127" height="35" border="0" id="Image7" /></a>
</td>

<td>
<a href="contact.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','image/contactH.png',1)"><img src="image/contact.png" name="Image8" width="143" height="36" border="0" id="Image8" /></a>
</td>

</tr>
</table>

</div>

</div>

</div>


<div align="center">

<div id="cont" align="left" style="position:relative; top:140px; width:1024px; height:400px;">
<center style="color:#A61515; font-size:26px; font-weight:200;">mlReports Intro</center>
<center style='color:#000; font-size:20px; font-weight:150;'>A system for generating medico-legal reports</center>

</div>


<div id="footy" align="right" style="position:relative; left:-2px; top:140px;background-color:#FFF; background-image:url(image/footer.png); color:#FFF; height:31px; width:1022px; overflow:hidden;">
<a href="index.html" class="l">Home</a> | 
<a href="about.html" class="l">About Us</a> | 
<a href="service.html" class="l">Services</a> | 
<a href="support.html" class="l">Support</a> | 
<a href="contact.html" class="l">Contact Us</a> | 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="mlr/index.html" class="l">Login</a> | 
<a href="mlr/register.html" class="l">Register</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>

<div id="cont2" style="width:1024px; position:relative;" align="left">
<p style="position:relative; top:-200px; margin-left:20px; margin-right:20px; width:750px; float:left;" align="left">
Currently, the system aims at generating RTA reports only, but furure support for other types of reports is planned.
<br /><br />
The advantage of this system is that you don't have to go through any lengthy installation procedures and as long as your computer can run a word-processor, you can view the reports we generate for you. Come to think about it, even if you dont have a word-processor, you can still create the report and view it later.
<br /><br />
Also, since the report we generate for you can be edited using word, if the solicitor asks you to change one word, you don't have to go through any loops, just open the document and change that one word, and send the report off to the solicitor within 5 minutes...
</p>

<div style="float:right; width:200px; height:350px; background-image:url(image/redR.png); background-repeat:no-repeat; position:relative; top:-300px; right:3px; color:#FFF; padding-top:130px;">

<ul>
<li style="margin-left:10px; font-size:20px;"><b>Easy to Edit</li><br />
<li style="font-size:20px; margin-left:5px;"><b>Word Documents</b></li><br />
<li style="font-size:20px;"><b>Intuitive Interface</li><br />
</ul>

</div>

</div>

</div>


</body>


</html>

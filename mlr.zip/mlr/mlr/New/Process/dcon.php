<?php

 mysql_connect("localhost", "ikazmico_root", "phantom") or die(mysql_error());
 mysql_select_db("ikazmico_mlrbt") or die(mysql_error());

//mysql_connect("localhost", "root", "phantom") or die(mysql_error());
//mysql_select_db("mlr") or die(mysql_error());

?>
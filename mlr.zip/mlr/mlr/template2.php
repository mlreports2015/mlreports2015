<?php

function bTop($par, $org, $id)
{


?>

<CENTER><H1><? echo "ML".$id;?></H1></CENTER>

<?php

include "dcon.php";

$s="select * from repGen where cid='$id' and org='".$org."'";
$q=mysql_query($s);
$n=mysql_num_rows($q);

if ($n>0)
{
	$r=mysql_fetch_array($q);
	echo '<center>This Report Has Been Generated <b style="font-size:large; color:#A61515;">'.$r['num'].'</b> Times.</center>';
	echo '<center>First Generated On <b style="font-size:large; color:#A61515;">'.date('d-m-Y', strtotime($r['dt'])).'</b>.</center>';
}
else
{
	echo '<center>This Report Has Been Generated <b style="font-size:large; color:#A61515;">0</b> Times.</center>';
}

?>

<br />
<br />

<CENTER>
<DIV align="center">

<div align="left" style="width:100%">
<div style="background-image:url(images/bgHead2.png); width:950px; background-repeat:no-repeat; height:45px; padding-top:10px;" align="left">
<A class="l2" href="det.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Details</A> 

<A class="l2" href="pmh.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">PMH</A> 

<A class="l2" href="accid.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Accident</A> 

<A class="l2" href="effect.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Symptoms</A> 

<A class="l2" href="treat.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Treatment</A> 

<A class="l2" href="life.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Life</A> 

<A class="l2" href="exam.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>"> Examination </A> 

<A class="l2" href="summary.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Summary</A> 

<A class="l2" href="prog.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Prognosis </A> 


<?php

include 'dcon.php';

$s="select * from mreps where id='$id' and org='$org'";
$qmed=mysql_query($s);
$rmed=mysql_fetch_array($qmed);

//echo $rmed['msg'];

if (strcmp($rmed['msg'],"The claimant's medical records were used in compiling this report.")==0)
{
?>

<A class="l2" href="mnote.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Medical Records </A> 

<?php
}

?>

<A class="l2" href="repgen.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Report</A>

</div>
</div>

<Div style="width:100%"></DIV>
</A>
</CENTER>

<br>


<CENTER><H1><?php echo $par; ?></H1></CENTER>

<?php
}
?>
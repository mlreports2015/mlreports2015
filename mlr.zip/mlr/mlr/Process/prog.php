<?
session_start();

include "../inc.php";


if (!isset($_SESSION['id']))
{
	rdrctr("Login Details Incorrect","index.html");
}
else
{
include "../dcon.php";

$o=$_SESSION['o'];

$id=$_POST['id'];

mysql_query("delete from prog where id=$id and org='$o'");

echo $_POST['tv'].'<br />';

if ($_POST['tv']>-1)
{
$i=0;
	while ($i<($_POST['tv']+1))
	{
		$x=$_POST['t'][$i];
echo $x."<br>";
		$y=$_POST['h'][$i];
		if (strcmp($y,'Block')==0)
		{
			$s="insert into prog set id=$id,prog='$x',org='$o'";
			echo "$s<br>";
			mysql_query($s);
		}
		$i++;
	}
}

	rdrctr("Added","../repgen.php?cid=$id");
// 	echo "<a style='font-size:large;' href='../repgen.php?cid=$id'>Click Here to Continue</a>";
}
?>
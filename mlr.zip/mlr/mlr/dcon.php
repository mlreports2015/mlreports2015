<?php

// mysql_connect("localhost", "ikazmico_root", "phantom") or die(mysql_error());
// mysql_select_db("ikazmico_test") or die(mysql_error());

// mysql_connect("localhost", "root", "") or die(mysql_error());
// mysql_select_db("mlreports") or die(mysql_error());

mysql_connect("localhost", "root", "") or die(mysql_error());
mysql_select_db("mlreport_mlrbt") or die(mysql_error());




/*mysql_connect("localhost", "root", "root") or die(mysql_error());
mysql_select_db("mlrbt") or die(mysql_error());*/


?>
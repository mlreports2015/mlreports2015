<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>mlReports Register</title>

<style>

a.li:link {
	color:#FFF;
	position:relative;
	left:32px;
	text-decoration:none;
	color: #FFF;
}

a.li:visited {
	color:#FFF;
	position:relative;
	left:32px;
	text-decoration:none;
	color: #FFF;
}

a.li:hover {
	color: #000;
}

a.li:active {
	color: #000;
}


a.l:link {
	color:#FFF;
	text-decoration:none;
	color: #FFF;
}

a.l:visited {
	color:#FFF;
	text-decoration:none;
	color: #FFF;
}

a.l:hover {
	color: #000;
}

a.l:active {
	color: #FF0000;
}


li
{
	font-size:16px;
	font-weight:200;
}

</style>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>


<script language="javascript" type="text/javascript">

//test variable
	var chk='1';
	var chkGV='';
	var count=0;


// trim blank space at the beginning and end of the string and return the length
function lnth(v)
{
	var t = v.replace(/(^\s*)/g, "");
	var t = t.replace(/(\s*$)/g, "");
	
	t=t.replace(/<&#91;^>&#93;*>/g, "");
	
	return t.length;
}


function validateFrm()
{
//grabbing values from form;
	var fn=document.getElementById('fn').value;
	var ln=document.getElementById('ln').value;
	
	var s=document.getElementById('s').value;
	
	var un=document.getElementById('un').value;
	
	var p1=document.getElementById('p1').value;
	var p2=document.getElementById('p2').value;
	
	var t=document.getElementById('ltel').value;
	var m=document.getElementById('mtel').value;
	
	var pe=document.getElementById('peml').value;
	var we=document.getElementById('weml').value;
	
	var a=document.getElementById('add').value;
	

	var fns=document.getElementById('fn');
	var lns=document.getElementById('ln');
	
	var ss=document.getElementById('s');
	
	var uns=document.getElementById('un');
	
	var p1s=document.getElementById('p1');
	var p2s=document.getElementById('p2');
	
	var ts=document.getElementById('ltel');
	var ms=document.getElementById('mtel');
	
	var pes=document.getElementById('peml');
	var wes=document.getElementById('weml');
	
	var as=document.getElementById('add');


//setting test variables
	chk='1';
	count=0;
	
//testing compulsary fields are non-blank and don't contain only white-spaces
	if (lnth(fn)==0 || lnth(ln)==0 || lnth(s)==0 || lnth(un)==0 || lnth(p1)==0 || lnth(p2)==0)
	{
		alert ('Not All The Compulsary Fields Have Been Filled In...');
		chk='0';
		
		if (lnth(fn)==0)
		{
			fns.style.backgroundColor='#A61515';
		}
		
		if (lnth(ln)==0)
		{
			lns.style.backgroundColor='#A61515';
		}
		
		if (lnth(s)==0)
		{
			ss.style.backgroundColor='#A61515';
		}
		
		if (lnth(un)==0)
		{
			uns.style.backgroundColor='#A61515';
		}
		
		if (lnth(p1)==0)
		{
			p1s.style.backgroundColor='#A61515';
			p2s.style.backgroundColor='#A61515';
		}
	}
	
	if (lnth(t)==0 && lnth(m)==0)
	{
		alert('Please Fill In Either The Telephone Or Mobile Field');
		chk='0';
		
		ts.style.backgroundColor='#A61515';
		ms.style.backgroundColor='#A61515';
	}
	
	if (lnth(pe)==0 && lnth(we)==0)
	{
		alert('Please Fill In Either Personal Email or Work Email Field');
		chk='0';
		
		pes.style.backgroundColor='#A61515';
		wes.style.backgroundColor='#A61515';
	}
	
	if (p1!=p2)
	{
		alert('Passwords Do Not Match');
		chk='0';
		p1s.style.backgroundColor='#A61515';
		p2s.style.backgroundColor='#A61515';
	}
	
	if (p1.length<6)
	{
		alert('Password too short');
		chk='0';
		p1s.style.backgroundColor='#A61515';
		p2s.style.backgroundColor='#A61515';
	}
	
/*	var reN = /[0-9]+?/;
	var reA =/[a-zA-Z]+?/;
	if (!reN.test(p1.value) || !reA.test(p1.value))
	{
		alert('Password should contain atleast one alphabetic and atleast one numeric character');
		chk='0';
		p1s.style.backgroundColor='#A61515';
		p2s.style.backgroundColor='#A61515';
	}*/
	
	
	if (checkemail(pe)==false && lnth(pe)>0)
	{
		alert('Personal Email Address Can not Be Validated');
		pes.style.backgroundColor='#A61515';
		chk='0';
	}
		
	if (checkemail(we)==false && lnth(we)>0)
	{
		alert('Work Email Address Can not Be Validated');
		pes.style.backgroundColor='#A61515';
		chk='0';
	}
	
	chkGV='un';
	call_register('uName', un, 'user');
	
	chkGV='peml';
	call_register('peml', pe, 'user');
	
	chkGV='weml';
	call_register('weml', we, 'user');
	
	chkGV='name';
	call_register('name', un, 'login');

	
	if (chk=='1')
	{
		subFrm();
	}
}



function subFrm()
{
	document.Frm.submit();
}



var testresults;

function checkemail(str)
{
// var str=document.validation.emailcheck.value
 var filter=/^.+@.+\..{2,3}$/

 if (filter.test(str))
 {
    testresults=true
 }
 else
 {
    testresults=false
 }
 return (testresults)
}



function postRequest(strURL)
{

  var xmlHttp;
  
  if(window.XMLHttpRequest)
  { // For Mozilla, Safari, ...
  
  	var xmlHttp = new XMLHttpRequest();
  
  }
  
  else if(window.ActiveXObject)
  { // For Internet Explorer
  
  	var xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  
  }
  
  xmlHttp.open('POST', strURL, true);
  
  xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  
  xmlHttp.onreadystatechange = function()
  {
  
  	if (xmlHttp.readyState == 4)
	{
  
	  updatepage(xmlHttp.responseText);
  
  	}
  
  }
  
  xmlHttp.send(strURL);

}


function updatepage(str)
{
	if(str == "no")
	{
		
		if (count==0)
		{
			chk='0';
			alert("Username Already Exists, Please Choose a Different Username");
			count=count+1;
			document.getElementById('un').style.backgroundColor='#C6B677';
		}
		else if (count==1)
		{
			chk='0';
			alert("Personal Email Address Already In Use, If You Have Lost Your Password/Username, Please Contact Our Support Team.");
			count=count+1;
			document.getElementById('peml').style.backgroundColor='#C6B677';
		}
		else if (count==2)
		{
			chk='0';
			alert("Work Email Address Already In Use, If You Have Lost Your Password/Username, Please Contact Our Support Team.");
			count=0;
			document.getElementById('weml').style.backgroundColor='#C6B677';
		}
		else if (count==3)
		{
			chk='0';
			alert("Username Already Exists, Please Choose a Different Username");
			count=0;
			document.getElementById('un').style.backgroundColor='#C6B677';
		}

	}
	else if (str="yes")
	{
		count=count+1;
	}
	else
	{
		chk='0';
		alert('Lost Connection With The Server, Please Submit Again');
	}
}


function call_register(chkr, val, tbl)
{

  var url = "register.php?chk="+chkr+"&val="+val+"&tbl="+tbl;
  if (count==0)
  {
	  alert('Checking If Username Is Already Registered');
  }
  else if (count==3)
  {
	  alert('Checking If Username Is Already Registered');
  }
  else if (count==1)
  {
	  alert('Checking If Personal Email Address Is Already Registered');
  }
  else if (count==2)
  {
	  alert('Checking If Work Email Address Is Already Registered');
  }
  
  postRequest(url);

}

</script>

</head>


<body style="margin-top:0px;" topmargin="0" marginheight="0" onload="MM_preloadImages('image/aboutH.png','image/supportH.png','image/contactH.png','image/homeH.png','image/serviceH.png')">

<div align="center" style="position:relative; top:-15px;">
<div align="left" style="width:1024px; background-color:#FFF; ">

<div id="logo" style="width:383px;height:177px; float:left; z-index:4">
<img src="image/Logo.png" />
</div>

<div id="redRound" style="position:relative; float:right; width:431px; height:59; background-image:url(image/redCurve.png); color:#fff;">
<table>
<tr>
<td>
<a class="li" href="index.html">Login</a>
</td>
<td width="90" align="right">
<a class="li" href="register.html">Register</a>
</td>
<td width='350' align="right">
Tel : 0161 839 3703
</td>
</tr>
</table>
</div>
<p>&nbsp;</p>

<div style="position:relative; left:-45px; top:40px; z-index:2; vertical-align:middle; float:right;">

<table style="vertical-align:middle;">
<tr>

<td>
  <a href="../home.html" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image2','','image/homeH.png',1)"><img src="images/home.png" name="Image2" width="97" height="34" border="0" id="Image2" /></a>
</td>


<td>
  <a href="../about.html" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image7','','image/aboutH.png',1)"><img src="image/about.png" name="Image7" width="129" height="34" border="0" id="Image7" /></a></td>


<td>
  <a href="../service.html" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image8','','image/serviceH.png',1)"><img src="image/service.png" name="Image8" width="114" height="34" border="0" id="Image8" /></a></td>


<td>
  <a href="../support.html" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image5','','image/supportH.png',1)"><img src="image/support.png" name="Image5" width="127" height="35" border="0" id="Image5" /></a>
</td>


<td>
  <a href="../contact.html" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image6','','image/contactH.png',1)"><img src=  "image/contact.png" name="Image6" width="143" height="36" border="0" id="Image6" /></a>
</td>

</tr>
</table>

</div>

</div>

</div>


<div align="center">

<div align="left" style=" position:relative; width:1024px; height:550px; top:70px;">
<center style="color:#A61515; font-size:26px; font-weight:200;">mlReports Registration</center>
<center style='color:#000; font-size:20px; font-weight:150;'>For Individual Users</center>

</div>


<div align="right" style="position:relative; left:-2px; top:140px;background-color:#FFF; background-image:url(image/footer.png); color:#FFF; height:31px; width:1022px; overflow:hidden;">
<a href="../index.html" class="l">Home</a> | 
<a href="../about.html" class="l">About Us</a> | 
<a href="../service.html" class="l">Services</a> | 
<a href="../support.html" class="l">Support</a> | 
<a href="../contact.html" class="l">Contact Us</a> | 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="index.html" class="l">Login</a> | 
<a href="register.html" class="l">Register</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>

<div style="width:1024px; position:relative; top:-475px;" align="left">

<form name="Frm" id="Frm" action="expRegP.php" method="post">

<table style="margin-top:150px;" align="center">

<tr>
<Td>
Status
</Td>
<td>
<input type="text" readonly="readonly" value="Expert" name="st" />
</td>
<td>
Login Name
</td>
<td>
<input readonly="readonly" type="text" name="un" id="un" value="<?php echo $_GET['un']; ?>" />
</td>
</tr>

<tr>
<td>
GMC Number
</td>
<td>
<input type="text" name="gmc" />
</td>
<td>
Signature
</td>
<td>
<input type="file" name="sig" />
</td>
</tr>

<tr>
<td colspan="4" height="15px">
</td>
</tr>

<tr>
<td>
Qualifications
</td>
<td colspan="3" >
<textarea name="qualif" rows="4" cols="50" id="add"></textarea>
</td>
</tr>

<tr>
<td colspan="4" height="25px">
</td>
</tr>
<tr>
<td colspan="4" align="center">
<input type="button" value="Submit" onclick="validateFrm();" />
</td>
</tr>

</table>

</form>

<div style="float:right; width:200px; height:350px; background-image:url(image/redR.png); background-repeat:no-repeat; position:relative; top:-325px; right:3px; color:#FFF; padding-top:130px;">

<ul>
<li style="margin-left:10px; font-size:20px;"><b>Easy to Edit</li><br />
<li style="font-size:20px; margin-left:5px;"><b>Word Documents</b></li><br />
<li style="font-size:20px;"><b>Intuitive Interface</li><br />
</ul>

</div>

</div>

</div>


</body>


</html>

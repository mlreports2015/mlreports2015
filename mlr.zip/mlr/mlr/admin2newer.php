#<?php

include 'template.php';

head('Admin','','','','','');


if (!isset($_SESSION['id']))
{
	rdrctr("Login Details Incorrect","index.html");
}
else
{
//////////////////////// - claimant add - ///////////////////////////
	include "dcon.php";
	
	$id=id($_SESSION['o']);
	$id=$id+1;
	
//	echo $id;

	$t=$_POST['tt'];
	$fn=$_POST['cf'];
	$ln=$_POST['cl'];
	$gen=$_POST['gend'];
	$dob=date('Y-m-d', strtotime($_POST['dob']));
	$doa=date('Y-m-d', strtotime($_POST['doa']));
	$doe=date('Y-m-d', strtotime($_POST['doe']));
	$tm=$_POST['tm'];
	
	$org=$_SESSION['o'];
	$nm=$_SESSION['n'];
	
	$cc1=$_POST['cc1'];
	$cc2=$_POST['cc2'];
	$ca1=$_POST['ca1'];
	$ca2=$_POST['ca2'];
	$cty=$_POST['cty'];
	$cp=$_POST['cp'];
	$ce=$_POST['ce'];
	$cAN=$_POST['aN2'];
	$car=$_POST['aRef'];
	$cSN=$_POST['sN2'];
	$csr=$_POST['sRef'];
	$ll=$_POST['lat'].','.$_POST['long'];
//	$cr=$_POST['c'];


	if ($_SESSION['chkrer']==1)
	{
		$sqlC="insert into claimant set org = '$org', cid='$id', ct = '$t', cfn = '$fn', cln = '$ln', cdb = '$dob', emp = '', cda = '$doa', cde = '$doe', ca1 = '$ca1', ca2 = '$ca2', cp = '$cp', cc1 = '$cc1', cc2 = '$cc2', ce = '$ce', cage ='$cAN', cageref = '$car', csol ='$cSN', csolref = '$csr', gen = '$gen', clid =1, stat = '', doc = '$nm', ll='$ll', cty='$cty'";
		mysql_query($sqlC);
	
//	$id=mysql_insert_id();
	
	
//////////////////////// - special instructions - ///////////////////////////
		$cr2=$_POST['soi'];

		if ($cr2==0)
		{
			$s4="insert into soi set cid='$id', chk='None',org='$org'";
			mysql_query($s4);
		}
		else
		{
			$soiT=$_POST['soiT'];
			$s4="insert into soi set cid=$id, chk='$soiT',org='$org'";
			mysql_query($s4);
		}
	
	
//////////////////////// - booking instructions - ///////////////////////////	

		$s3="insert into booki set cid='$id', bi='".$_POST['bi']."',org='$org'";
		mysql_query($s3);
	}
	
	
	if (strtotime($_POST['doe'])==strtotime('01-01-1200'))
	{	
?>

<form action="" method="post">
<table align="center" width="300" border="0">
<tr>
<th colspan="3" align="center">
Case Entered with Reference : <?php echo $id;?>
</th>
</tr>
<tr>
<th colspan="3" align="center" style="color:#900;">
No Examination Date Entered!<br />&nbsp;<br />&nbsp;
</th>
</tr>
<tr>
<th colspan="3" align="center" style="color:#900;">
Create Reminder
</th>
</tr>
<tr>
<td>
Date
</td>
<td>
<input type="text" value="" id="eDat" name="eDat" />
<a href='#' onClick="setYears(1900, 2012); showCalender(this, 'eDat');"><img src='images/calender.png' border=0></a><a href='#' onClick="document.getElementById('eDat').value='';"><img src='images/clear.png' border=0></a>
</td>
<td>
<input type="button" value="Create" />
</td>
</tr>
</table>
</form>

<?php
	}
	else
	{
		$s="select * from app where dt='".date('Y-m-d', strtotime($doe))."' and org='$org' and dr='$nm'";
		$q=mysql_query($s);
		$c=mysql_num_rows($q);
		
		if ($c==0)
		{
?>

<form action="" method="post">
<table align="center" width="600" border="0">
<tr>
<th colspan="4" align="center">
Case Entered with Reference : <?php echo $id;?>
</th>
</tr>
<tr>
<th colspan="4" align="center" style="color:#900;">
No Clinic Booked For Examination Date <?php echo $doe; ?><br />&nbsp;<br />&nbsp;
</th>
</tr>
<tr>
<th colspan="4" align="center" style="color:#900;">
Book Clinic
</th>
</tr>
<tr>
<td>
Start Time
</td>
<td>
<input type="text" value="hh:mm" name="st" />
</td>
<td>
End Time
</td>
<td>
<input type="text" value="hh:mm" name="et" />
</td>
</tr>
<tr>
<td colspan="4" align="center">
<input type="button" value="Create" />
</td>
</tr>
</table>
</form>

<?php
		}
		else
		{
			if ($_SESSION['chkrer']==1)
			{
				$s="delete from appoint where dt='$doe' and tm='$tm' and org='".$_SESSION['o']."' and dr='".$_SESSION['n']."'";
				echo $s;
				$q=mysql_query($s);
				
				$s="delete from stat where dt='$doe' and tm='$tm' and org='".$_SESSION['n']."' and dr='".$_SESSION['o']."'";
				echo $s;
				$q=mysql_query($s);
				
				$s="insert into appoint set id='$id', dt='$doe', tm='$tm', dr='".$_SESSION['n']."', org='".$_SESSION['o']."'";
				echo $s;
				$q=mysql_query($s);
				
				$s="insert into stat set id='$id', dt='$doe', tm='$tm', dr='".$_SESSION['n']."', stat='0', org='".$_SESSION['o']."'";
				echo $s;
				$q=mysql_query($s);
				
				red('home.php');
			}
		}
	}
?>

<table id='calenderTable'>
<tbody id='calenderTableHead'>
<tr>
<td colspan='4' align='left'>
<select onChange="showCalenderBody(createCalender(document.getElementById('selectYear').value, this.selectedIndex, false));" id='selectMonth'>
<option value='0'>January</OPTION>
<option value='1'>February</option>
<option value='2'>March</option>
<option value='3'>April</option>
<option value='4'>May</option>
<option value='5'>June</option>
<option value='6'>July</option>
<option value='7'>August</option>
<option value='8'>September</option>
<option value='9'>October</option>
<option value='10'>November</option>
<option value='11'>December</option>
</SELECT>
</td>
<td colspan='2' align='center'><select onChange="showCalenderBody(createCalender(this.value, document.getElementById('selectMonth').selectedIndex, false));" id='selectYear'></select></td>
<td align='right'><a href='#' onClick='closeCalender();'>X</a></td>
</tr>
</tbody>
<tbody id='calenderTableDays'>
<tr style=''>
<td>Su</td><td>Mo</td><td>Tu</td><td>We</td><td>Thu</td><td>Fr</td><td>Sa</td>
</tr>
</tbody>
<tbody id='calender'></tbody>
</table>

<table height=400px><tr><td></td></tr></table>

</body>
</html>

<?php
$_SESSION['chkrer']=0;
}
?>
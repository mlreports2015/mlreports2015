function format()
{
	if (document.getElementById('sentence').value==1)
	{
		if (document.getElementById('veh').value== 'motor-bike' || document.getElementById('veh').value == 'bicycle')
		{
			accidBike();
		}
		else if (document.getElementById('veh').value == 'on foot')
		{
			accidFoot();
		}
		else if (document.getElementById('veh').value == 'mini-bus' || document.getElementById('veh').value == 'MPV' || document.getElementById('veh').value == 'jeep' || document.getElementById('veh').value == 'estate')
		{
			accidBig();
		}
		else
		{
			accid();
		}
	}
	else if (document.getElementById('sentence').value==2)
	{
		if (document.getElementById('veh').value== 'motor-bike' || document.getElementById('veh').value == 'bicycle')
		{
			accid2Bike();
		}
		else if (document.getElementById('veh').value == 'on foot')
		{
			accid2Foot();
		}
		else if (document.getElementById('veh').value == 'mini-bus' || document.getElementById('veh').value == 'MPV' || document.getElementById('veh').value == 'jeep' || document.getElementById('veh').value == 'estate')
		{
			accid2Big();
		}
		else
		{
			accid2();
		}
	}
	else if (document.getElementById('sentence').value==3)
	{
		if (document.getElementById('veh').value== 'motor-bike' || document.getElementById('veh').value == 'bicycle')
		{
			accid3Bike();
		}
		else if (document.getElementById('veh').value == 'on foot')
		{
			accid3Foot();
		}
		else if (document.getElementById('veh').value == 'mini-bus' || document.getElementById('veh').value == 'MPV' || document.getElementById('veh').value == 'jeep' || document.getElementById('veh').value == 'estate')
		{
			accid3Big();
		}
		else
		{
			accid3();
		}
	}
}

function accid()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
	}
	
	var d='The accident occurred '+tm+'. '+wv+tt+' '+nm+' occupied the '+sa+"'s seat in a "+ve+'. '+gg+' '+sb+' wearing a seatbelt. A head restraint '+hr+' fitted. An air-bag '+ab+' fitted';
	
	if (ab!='was not')
	{
		if (abd=='deployed')
		{
			d=d+", and it deployed. ";
		}
		else
			d=d+", but it did not deploy. ";
	}
	else
		d=d+". ";

	d=d+"At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+". The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"The impact came from the "+im+". ";

	if (dmg!="unknown")
		d=d+"Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}


//////////////////////////////////////////////////////--format 2--/////////////////////////////////////////////////////////////////

function accid2()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
	}
	
	var d='* The accident occurred '+tm+'. '+wv;
	
	d=d+'<br>* '+tt+' '+nm+' occupied the '+sa+"'s seat in a "+ve+'.'
	
	d=d+'<br>* '+gg+' '+sb+' wearing a seatbelt.';
	
	d=d+'<br>* A head restraint '+hr+' fitted.'
	
	d=d+'<br>* An air-bag '+ab+' fitted';
	
	if (ab!='was not')
	{
		if (abd=='deployed')
		{
			d=d+", and it deployed. ";
		}
		else
			d=d+", but it did not deploy. ";
	}
	else
		d=d+". ";

	d=d+"<br>* At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+".";
	d=d+"<br>* The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"<br>* The impact came from the "+im+". ";

	if (dmg!="unknown")
	d=d+"Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+'<br>* '+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+'<br>* '+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}


function accid3()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var ind=1;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	var d='<strong><i>5.'+ind+' Accident Time</i></strong><br>The accident occurred '+tm+'.';
	ind=ind+1;
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	
	d=d+'<br><strong><i>5.'+ind+' Seating and Vehicle</i></strong><br>* '+tt+' '+nm+' occupied the '+sa+"'s seat in a "+ve+'.'
	ind=ind+1;
	
	d=d+'<br>* '+gg+' '+sb+' wearing a seatbelt.';
	
	d=d+'<br>* A head restraint '+hr+' fitted.'
	
	d=d+'<br>* An air-bag '+ab+' fitted';
	
	if (ab!='was not')
	{
		if (abd=='deployed')
		{
			d=d+", and it deployed. ";
		}
		else
			d=d+", but it did not deploy. ";
	}
	else
		d=d+". ";

	d=d+"<br><strong><i>5."+ind+" Accident Circumstances</i></strong><br>* At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+".";
	ind=ind+1;
	d=d+"<br>* The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"<br>* The impact came from the "+im+". ";

	if (dmg!="unknown")
	d=d+"<br><strong><i>5."+ind+" Aftermath of Accident</i></strong><br>* Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+'<br>* '+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+'<br>* '+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}



function accidBike()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
	}
	
	var d='The accident occurred '+tm+'. '+wv+tt+' '+nm+' occupied the '+sa+"'s seat on a "+ve+'. ';
	
	d=d+gg+' was '+hr+'. ';
	

	d=d+"At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+". The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"The impact came from the "+im+". ";

	if (dmg!="unknown")
		d=d+"Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}


//////////////////////////////////////////////////////--format 2--/////////////////////////////////////////////////////////////////

function accid2Bike()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
	}
	
	var d='* The accident occurred '+tm+'. '+wv;
	
	d=d+'<br>* '+tt+' '+nm+' occupied the '+sa+"'s seat on a "+ve+'.'
	
	d=d+'<br>* '+gg+' was '+hr+'. ';
	
	d=d+"<br>* At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+".";
	d=d+"<br>* The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"<br>* The impact came from the "+im+". ";

	if (dmg!="unknown")
	d=d+"Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+'<br>* '+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+'<br>* '+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}


function accid3Bike()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var ind=1;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	var d='<strong><i>5.'+ind+' Accident Time</i></strong><br>The accident occurred '+tm+'.';
	ind=ind+1;
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	
	d=d+'<br><strong><i>5.'+ind+' Seating and Vehicle</i></strong><br>* '+tt+' '+nm+' occupied the '+sa+"'s seat on a "+ve+'.'
	ind=ind+1;
	
	d=d+'<br>* '+gg+' was '+hr+'. ';
	
	d=d+"<br><strong><i>5."+ind+" Accident Circumstances</i></strong><br>* At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+".";
	ind=ind+1;
	d=d+"<br>* The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"<br>* The impact came from the "+im+". ";

	if (dmg!="unknown")
	d=d+"<br><strong><i>5."+ind+" Aftermath of Accident</i></strong><br>* Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+'<br>* '+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+'<br>* '+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}



function accidBig()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
	}
	
	var d='The accident occurred '+tm+'. '+wv+tt+' '+nm+' '+sa+" in a "+ve+'. '
	
	if (sb!='')
	{
		d=d+gg+' '+sb+' wearing a seatbelt. ';
	}
	
	if (ab!='')
	{
		d=d+'A head restraint '+hr+' fitted. An air-bag '+ab+' fitted';
		
		if (ab!='was not')
		{
		  if (abd=='deployed')
		  {
			  d=d+", and it deployed. ";
		  }
		  else
			  d=d+", but it did not deploy. ";
		  }
		else
		{
			d=d+". ";
		}
	}

	d=d+"At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+". The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"The impact came from the "+im+". ";

	if (dmg!="unknown")
		d=d+"Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}


//////////////////////////////////////////////////////--format 2--/////////////////////////////////////////////////////////////////

function accid2Big()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
	}
	
	var d='* The accident occurred '+tm+'. '+wv;
	
	d=d+'<br>* '+tt+' '+nm+' '+sa+" in a "+ve+'.'
	
	
	if (sb!='')
	{
		d=d+'<br>* '+gg+' '+sb+' wearing a seatbelt.';
	}
	
	if (hr!='')
	{	
		d=d+'<br>* A head restraint '+hr+' fitted.'
	}
	
	if (ab!='')
	{
	  d=d+'<br>* An air-bag '+ab+' fitted';
	  
	  if (ab!='was not')
	  {
		  if (abd=='deployed')
		  {
			  d=d+", and it deployed. ";
		  }
		  else
			  d=d+", but it did not deploy. ";
	  }
	  else
	  {
		  d=d+". ";
	  }
	}

	d=d+"<br>* At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+".";
	d=d+"<br>* The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"<br>* The impact came from the "+im+". ";

	if (dmg!="unknown")
	d=d+"Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+'<br>* '+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+'<br>* '+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}


function accid3Big()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var ind=1;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	var d='<strong><i>5.'+ind+' Accident Time</i></strong><br>The accident occurred '+tm+'.';
	ind=ind+1;
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	
	d=d+'<br><strong><i>5.'+ind+' Seating and Vehicle</i></strong><br>* '+tt+' '+nm+' '+sa+" in a "+ve+'.'
	ind=ind+1;
	
	if (sb!='')
	{
		d=d+'<br>* '+gg+' '+sb+' wearing a seatbelt.';
	}
	
	if (hr!='')
	{
		d=d+'<br>* A head restraint '+hr+' fitted.'
	}
	
	if (ab!='')
	{
	  d=d+'<br>* An air-bag '+ab+' fitted';
	  
	  if (ab!='was not')
	  {
		  if (abd=='deployed')
		  {
			  d=d+", and it deployed. ";
		  }
		  else
			  d=d+", but it did not deploy. ";
	  }
	  else
	  {
		  d=d+". ";
	  }
	}

	d=d+"<br><strong><i>5."+ind+" Accident Circumstances</i></strong><br>* At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+".";
	ind=ind+1;
	d=d+"<br>* The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"<br>* The impact came from the "+im+". ";

	if (dmg!="unknown")
	d=d+"<br><strong><i>5."+ind+" Aftermath of Accident</i></strong><br>* Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+'<br>* '+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+'<br>* '+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}




function accidFoot()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
	}
	
	var d='The accident occurred '+tm+'. '+wv+tt+' '+nm+' was on foot. ';
	
	var prov=onatdoc();
	
	d=d+"At the moment of impact, the claimant was "+st+" "+prov+" a "+lo+". The claimant "+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"The impact came from the "+im+". ";

	d=d+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}


//////////////////////////////////////////////////////--format 2--/////////////////////////////////////////////////////////////////

function accid2Foot()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
	}
	
	var d='* The accident occurred '+tm+'. '+wv;
	
	d=d+'<br>* '+tt+' '+nm+' occupied the '+sa+"'s seat on a "+ve+'.'
	
	d=d+'<br>* '+gg+' was '+hr+'. ';
	
	d=d+"<br>* At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+".";
	d=d+"<br>* The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"<br>* The impact came from the "+im+". ";

	if (dmg!="unknown")
	d=d+"Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+'<br>* '+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+'<br>* '+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}


function accid3Foot()
{

// 	var id=document.getElementById('id').value;
	var tm=document.getElementById('t').value;
	var sa=document.getElementById('loc').value;
	var ve=document.getElementById('veh').value;
	var aw=document.getElementById('aw').value;
	var sb=document.getElementById('sb').value;
	var hr=document.getElementById('hr').value;
	var ab=document.getElementById('ab').value;
	var abd=document.getElementById('abd').value;
	var st=document.getElementById('stat').value;
	var lo=document.getElementById('locat').value;
	var co=document.getElementById('cost').value;
	var im=document.getElementById('impact').value;
	var th=document.getElementById('thr').value;
	var dmg=document.getElementById('dam').value;
	var spd=document.getElementById('spe').value;
	var gc=document.getElementById('gc').value;
	
	var tt=document.getElementById('tt').value;
	var nm=document.getElementById('cln').value;
	var gen=document.getElementById('gnd').value;

	var vis=document.getElementById('vis').value;
	var wcon=document.getElementById('wcond').value;
	
	var ind=1;
	
	var gg='';
	
	if (gen=='m')
		gg='He';
	else
		gg='She';
	
	var wv='';
	
	var d='<strong><i>5.'+ind+' Accident Time</i></strong><br>The accident occurred '+tm+'.';
	ind=ind+1;
	
	if (wcon!='' && vis!='')
	{
		wv='It was '+wcon+' and visibility was '+vis+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	else if (wcon!='' && vis=='')
	{
		wv='It was '+wcon+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	else if (wcon=='' && vis!='')
	{
		wv='Visibility was '+vis+'. ';
		d=d+'<br><strong><i>5.'+ind+' Visibility</i></strong><br>'+wv;
		ind=ind+1;
	}
	
	d=d+'<br><strong><i>5.'+ind+' Seating and Vehicle</i></strong><br>* '+tt+' '+nm+' occupied the '+sa+"'s seat on a "+ve+'.'
	ind=ind+1;
	
	d=d+'<br>* '+gg+' was '+hr+'. ';
	
	d=d+"<br><strong><i>5."+ind+" Accident Circumstances</i></strong><br>* At the moment of impact, the claimant's "+ve+" was "+st+" "+lo+".";
	ind=ind+1;
	d=d+"<br>* The claimant's "+ve+' '+co+' '+aw;

	if (spd!="")
		d=d+" at "+spd+". ";
	else
		d=d+". The speed of the impact is not known. ";

	d=d+"<br>* The impact came from the "+im+". ";

	if (dmg!="unknown")
	d=d+"<br><strong><i>5."+ind+" Aftermath of Accident</i></strong><br>* Its force was sufficient to "+dmg+" the "+ve+". ";
	else
		d=d+"The damage caused to the "+ve+" is not known. ";



	d=d+'<br>* '+tt+' '+nm+' was thrown '+th+'. ';


	if (gc!='')
	{
		d=d+'<br>* '+gg+' '+gc;
	}
	
	document.getElementById('accident').innerHTML=d;
}





function idex0(chosen)
{
	if (chosen == 'motor-bike' || chosen == 'bicycle')
	{
		bikeSeat();
		bikeBelt();
		bikeHead();
		bikeBag();
		bikeLocation();
		bikeState();
		bikeImpact();
		bikeThrow();
		bikeDamage();
		bikeGotUp();
	}
	else if (chosen == 'on foot')
	{
		footSeat();
		footBelt();
		footHead();
		footBag();
		footLocation();
		footState();
		footImpact();
		footThrow();
		footDamage();
		footGotUp();
	}
	else if (chosen == 'mini-bus' || chosen == 'MPV' || chosen == 'jeep' || chosen == 'estate')
	{
		bigSeat();
		bigBelt();
		bigHead();
		bigBag();
		bigState();
		bigImpact();
		bigThrow();
		bigDamage();
		bigGotUp();
		bigLocation();
	}
	else
	{
		carSeat();
		carBelt();
		carHead();
		carBag();
		carState();
		carImpact();
		carThrow();
		carDamage();
		carGotUp();
		carLocation();
	}
	
}


function bikeSeat()
{
	var selbox = document.frm.loc;
	selbox.options.length=0;
	
	  selbox.options[selbox.options.length] = new Option('driver','driver');
	  selbox.options[selbox.options.length] = new Option('rider','rider');
	  selbox.options[selbox.options.length] = new Option('pillion','pillion');
}

function bikeBelt()
{
	var selbox = document.frm.sb;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function bikeHead()
{
	var selbox = document.frm.hr;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('wearing helmet','wearing a helmet');
	selbox.options[selbox.options.length] = new Option('not wearing helmet','not wearing a helmet');
}

function bikeBag()
{
	var selbox = document.frm.ab;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
	
	
	var selbox = document.frm.abd;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function bikeLocation()
{
	var selbox = document.frm.locat;
	selbox.options.length=0;

	  selbox.options[selbox.options.length] = new Option('main road','on a main road');
	  selbox.options[selbox.options.length] = new Option('traffic light','at a set of traffic lights');
	  selbox.options[selbox.options.length] = new Option('side road','on a side road');
	  selbox.options[selbox.options.length] = new Option('residential street','in a residential street');
	  selbox.options[selbox.options.length] = new Option('pelican crossing','at a pelican crossing');
	  selbox.options[selbox.options.length] = new Option('car park','in a car park');
	  selbox.options[selbox.options.length] = new Option('parked','parked');
	  selbox.options[selbox.options.length] = new Option('country lane','in a country lane');
	  selbox.options[selbox.options.length] = new Option('junction','at a junction');
	  selbox.options[selbox.options.length] = new Option('round-about','at a round-about');
	  selbox.options[selbox.options.length] = new Option('mincunian way','on a mincunian way');
	  selbox.options[selbox.options.length] = new Option('motorway slip-road','on a motorway slip-road');
	  selbox.options[selbox.options.length] = new Option('motor way','on a motor way');
}

function bikeState()
{
	var selbox = document.frm.stat;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('stationary','stationary');
	selbox.options[selbox.options.length] = new Option('moving','moving');
	selbox.options[selbox.options.length] = new Option('parked','parked');
	selbox.options[selbox.options.length] = new Option('braking','braking');
	selbox.options[selbox.options.length] = new Option('slowing down','slowing down');
	selbox.options[selbox.options.length] = new Option('braking abruptly','braking abruptly');
}

function bikeImpact()
{
	var selbox = document.frm.impact;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('front','front');
	selbox.options[selbox.options.length] = new Option('rear','rear');
	selbox.options[selbox.options.length] = new Option('left side','left side');
	selbox.options[selbox.options.length] = new Option('right side','right side');
	selbox.options[selbox.options.length] = new Option('not known','not known');
}

function bikeThrow()
{
	var selbox = document.frm.thr;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('sideways','sideways');
	selbox.options[selbox.options.length] = new Option('forward then backward','forward then backward');
	selbox.options[selbox.options.length] = new Option('backward then forward','backward then forward');
	selbox.options[selbox.options.length] = new Option('left side','left side');
	selbox.options[selbox.options.length] = new Option('right side','right side');
	selbox.options[selbox.options.length] = new Option('in all directions','in all directions');
	selbox.options[selbox.options.length] = new Option('off the bike','off the bike');
	selbox.options[selbox.options.length] = new Option('off the left side of the bike','off the left side of the bike');
	selbox.options[selbox.options.length] = new Option('off the right side of the bike','off the right side of the bike');
	selbox.options[selbox.options.length] = new Option('over the bonnet of the vehicle that struck the bike','over the bonnet of the vehicle that struck the bike');
	selbox.options[selbox.options.length] = new Option('over the bonnet of the vehicle that collided with the bike','over the bonnet of the vehicle that collided with the bike');
	selbox.options[selbox.options.length] = new Option('over the hood of the vehicle that collided with the bike','over the hood of the vehicle that collided with the bike');
	selbox.options[selbox.options.length] = new Option('over the boot of the vehicle that struck the bike','over the boot of the vehicle that struck the bike');
	selbox.options[selbox.options.length] = new Option('over the boot of the vehicle that collided with the bike','over the boot of the vehicle that collided with the bike');
	selbox.options[selbox.options.length] = new Option('over the hood of the vehicle that collided with the bike','over the hood of the vehicle that collided with the bike');
}

function bikeDamage()
{
	var selbox = document.frm.dam;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('write-off','write-off');
	selbox.options[selbox.options.length] = new Option('extensive','cause extensive damage to');
	selbox.options[selbox.options.length] = new Option('moderate','cause moderate damage to');
	selbox.options[selbox.options.length] = new Option('mild','cause mild damage to');
	selbox.options[selbox.options.length] = new Option('unknown','unknown');
}

function bikeGotUp()
{
	var selbox = document.frm.gc;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('---','');
	selbox.options[selbox.options.length] = new Option('got off the bike unaided','got off the bike unaided.');
	selbox.options[selbox.options.length] = new Option('needed help to get off the bike','needed help to get off the bike.');
	selbox.options[selbox.options.length] = new Option('got up unaided','got up unaided.');
	selbox.options[selbox.options.length] = new Option('needed help to get up','needed help to get up.');
}



function footSeat()
{
	var selbox = document.frm.loc;
	selbox.options.length=0;
	
	  selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function footBelt()
{
	var selbox = document.frm.sb;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function footHead()
{
	var selbox = document.frm.hr;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function footBag()
{
	var selbox = document.frm.ab;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
	
	
	var selbox = document.frm.abd;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function footLocation()
{
	var selbox = document.frm.locat;
	selbox.options.length=0;
	
	  selbox.options[selbox.options.length] = new Option('pelican crossing','pelican crossing');
	  selbox.options[selbox.options.length] = new Option('footpath','footpath');
	  selbox.options[selbox.options.length] = new Option('main road','main road');
	  selbox.options[selbox.options.length] = new Option('main (pelican crossing)','main road from a pelican crossing');
	  selbox.options[selbox.options.length] = new Option('side road','side road');
	  selbox.options[selbox.options.length] = new Option('car park','car park');
	  selbox.options[selbox.options.length] = new Option('residential street','residential street');
	  selbox.options[selbox.options.length] = new Option('country lane','country lane');
	  selbox.options[selbox.options.length] = new Option('traffic lights','road at a set of traffic lights');
	  selbox.options[selbox.options.length] = new Option('junction','junction');
	  selbox.options[selbox.options.length] = new Option('round-about','round-about');
	  selbox.options[selbox.options.length] = new Option('mincunian way','mincunian way');
	  selbox.options[selbox.options.length] = new Option('motorway slip-road','motorway slip-road');
	  selbox.options[selbox.options.length] = new Option('motor way','motor way');
}

function footState()
{
	var selbox = document.frm.stat;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('standing','standing');
	selbox.options[selbox.options.length] = new Option('walking','walking');
	selbox.options[selbox.options.length] = new Option('walking','walking');
	selbox.options[selbox.options.length] = new Option('jogging','jogging');
	selbox.options[selbox.options.length] = new Option('jogging','jogging');
	selbox.options[selbox.options.length] = new Option('running','running');
	selbox.options[selbox.options.length] = new Option('running','running');
	selbox.options[selbox.options.length] = new Option('crossing','crossing');
	selbox.options[selbox.options.length] = new Option('waiting to cross','waiting to cross');
}

function footImpact()
{
	var selbox = document.frm.impact;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('front','front');
	selbox.options[selbox.options.length] = new Option('rear','rear');
	selbox.options[selbox.options.length] = new Option('left side','left side');
	selbox.options[selbox.options.length] = new Option('right side','right side');
	selbox.options[selbox.options.length] = new Option('not known','not known');
}

function footThrow()
{
	var selbox = document.frm.thr;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('sideways','sideways');
	selbox.options[selbox.options.length] = new Option('forward','forward');
	selbox.options[selbox.options.length] = new Option('backward','backward');
	selbox.options[selbox.options.length] = new Option('right side','right side');
	selbox.options[selbox.options.length] = new Option('left side','left side');
	selbox.options[selbox.options.length] = new Option('in all directions','in all directions');
	selbox.options[selbox.options.length] = new Option('over the bonnet of the vehicle that struck the claimant','over the bonnet of the vehicle that struck the claimant');
	selbox.options[selbox.options.length] = new Option('over the bonnet of the vehicle that collided with the claimant','over the bonnet of the vehicle that collided with the claimant');
	selbox.options[selbox.options.length] = new Option('over the hood of the vehicle that collided with the claimant','over the hood of the vehicle that collided with the claimant');
	selbox.options[selbox.options.length] = new Option('over the boot of the vehicle that struck the claimant','over the boot of the vehicle that struck the claimant');
	selbox.options[selbox.options.length] = new Option('over the boot of the vehicle that collided with the claimant','over the boot of the vehicle that collided with the claimant');
	selbox.options[selbox.options.length] = new Option('over the hood of the vehicle that collided with the claimant','over the hood of the vehicle that collided with the claimant');
}

function footDamage()
{
	var selbox = document.frm.dam;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function footGotUp()
{
	var selbox = document.frm.gc;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('---','');
	selbox.options[selbox.options.length] = new Option('got up unaided','got up unaided.');
	selbox.options[selbox.options.length] = new Option('needed help to get up','needed help to get up.');
}



function bigSeat()
{
	var selbox = document.frm.loc;
	selbox.options.length=0;
	
	  selbox.options[selbox.options.length] = new Option('driver',"occupied the driver's seat");
	  selbox.options[selbox.options.length] = new Option('front-passenger','was the front-passenger');
	  selbox.options[selbox.options.length] = new Option('passenger','was a passenger');
	  selbox.options[selbox.options.length] = new Option('passenger (seated)','was a seated passenger');
	  selbox.options[selbox.options.length] = new Option('passenger (standing)','was standing');
	  selbox.options[selbox.options.length] = new Option('passenger (standing with support)','was standing with support');
	  selbox.options[selbox.options.length] = new Option('passenger (standing without support)','was standing without support');
	  selbox.options[selbox.options.length] = new Option('passenger (child seat)','was a passenger in a child seat');
	  selbox.options[selbox.options.length] = new Option('wheel-chair','was in a wheel-chair');
	  selbox.options[selbox.options.length] = new Option('pram','in a pram');
}

function bigBelt()
{
	var selbox = document.frm.sb;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Wearing Seatbelt','was');
	selbox.options[selbox.options.length] = new Option('Not Wearing Seatbelt','was not');
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function bigHead()
{
	var selbox = document.frm.hr;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Was Fitted','was');
	selbox.options[selbox.options.length] = new Option('Not Fitted','was not');
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function bigBag()
{
	var selbox = document.frm.ab;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Was Fitted','was');
	selbox.options[selbox.options.length] = new Option('Not Fitted','was not');
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
	
	
	var selbox = document.frm.abd;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('did not deploy','did not deploy');
	selbox.options[selbox.options.length] = new Option('deployed','deployed');
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function bigLocation()
{
	var selbox = document.frm.locat;
	selbox.options.length=0;

	  selbox.options[selbox.options.length] = new Option('main road','on a main road');
	  selbox.options[selbox.options.length] = new Option('side road','on a side road');
	  selbox.options[selbox.options.length] = new Option('car park','in a car park');
	  selbox.options[selbox.options.length] = new Option('pelican crossing','at a pelican crossing');
	  selbox.options[selbox.options.length] = new Option('residential street','in a residential street');
	  selbox.options[selbox.options.length] = new Option('country lane','in a country lane');
	  selbox.options[selbox.options.length] = new Option('traffic lights','at a set of traffic lights');
	  selbox.options[selbox.options.length] = new Option('junction','at a junction');
	  selbox.options[selbox.options.length] = new Option('round-about','at a round-about');
	  selbox.options[selbox.options.length] = new Option('mincunian way','on a mincunian way');
	  selbox.options[selbox.options.length] = new Option('motorway slip-road','on a motorway slip-road');
	  selbox.options[selbox.options.length] = new Option('motor way','on a motor way');
}

function bigState()
{
	var selbox = document.frm.stat;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('stationary','stationary');
	selbox.options[selbox.options.length] = new Option('moving','moving');
	selbox.options[selbox.options.length] = new Option('parked','parked');
	selbox.options[selbox.options.length] = new Option('braking','braking');
	selbox.options[selbox.options.length] = new Option('slowing down','slowing down');
	selbox.options[selbox.options.length] = new Option('braking abruptly','braking abruptly');
}

function bigImpact()
{
	var selbox = document.frm.impact;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('front','front');
	selbox.options[selbox.options.length] = new Option('rear','rear');
	selbox.options[selbox.options.length] = new Option('left side','left side');
	selbox.options[selbox.options.length] = new Option('right side','right side');
	selbox.options[selbox.options.length] = new Option('not known','not known');
}

function bigThrow()
{
	var selbox = document.frm.thr;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('sideways','sideways');
	selbox.options[selbox.options.length] = new Option('forward then backward','forward then backward');
	selbox.options[selbox.options.length] = new Option('backward then forward','backward then forward');
	selbox.options[selbox.options.length] = new Option('left side','left side');
	selbox.options[selbox.options.length] = new Option('right side','right side');
	selbox.options[selbox.options.length] = new Option('in all directions','in all directions');
}

function bigDamage()
{
	var selbox = document.frm.dam;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('write-off','write-off');
	selbox.options[selbox.options.length] = new Option('extensive','cause extensive damage to');
	selbox.options[selbox.options.length] = new Option('moderate','cause moderate damage to');
	selbox.options[selbox.options.length] = new Option('mild','cause mild damage to');
	selbox.options[selbox.options.length] = new Option('unknown','unknown');
}

function bigGotUp()
{
	var selbox = document.frm.gc;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('---','');
	selbox.options[selbox.options.length] = new Option('got off the vahicle unaided','got off the vahicle unaided.');
	selbox.options[selbox.options.length] = new Option('needed help to get off the vahicle','needed help to get off the vahicle.');
	selbox.options[selbox.options.length] = new Option('got up unaided','got up unaided.');
	selbox.options[selbox.options.length] = new Option('needed help to get up','needed help to get up.');
}




function carSeat()
{
	var selbox = document.frm.loc;
	selbox.options.length=0;
	
	  selbox.options[selbox.options.length] = new Option('driver','driver');
	  selbox.options[selbox.options.length] = new Option('front-passenger','front-passenger');
	  selbox.options[selbox.options.length] = new Option('passenger','passenger');
	  selbox.options[selbox.options.length] = new Option('passenger (child seat)','passenger (child seat)');
	  selbox.options[selbox.options.length] = new Option('passenger (booster seat)','passenger (booster seat)');
}

function carBelt()
{
	var selbox = document.frm.sb;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Wearing Seatbelt','was');
	selbox.options[selbox.options.length] = new Option('Not Wearing Seatbelt','was not');
}

function carHead()
{
	var selbox = document.frm.hr;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Was Fitted','was');
	selbox.options[selbox.options.length] = new Option('Not Fitted','was not');
	selbox.options[selbox.options.length] = new Option('Does Not Apply','');
}

function carBag()
{
	var selbox = document.frm.ab;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('Was Fitted','was');
	selbox.options[selbox.options.length] = new Option('Not Fitted','was not');
	
	
	var selbox = document.frm.abd;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('did not deploy','did not deploy');
	selbox.options[selbox.options.length] = new Option('deployed','deployed');
}

function carLocation()
{
	var selbox = document.frm.locat;
	selbox.options.length=0;

	  selbox.options[selbox.options.length] = new Option('main road','on a main road');
	  selbox.options[selbox.options.length] = new Option('side road','on a side road');
	  selbox.options[selbox.options.length] = new Option('car park','in a car park');
	  selbox.options[selbox.options.length] = new Option('pelican crossing','at a pelican crossing');
	  selbox.options[selbox.options.length] = new Option('residential street','in a residential street');
	  selbox.options[selbox.options.length] = new Option('country lane','in a country lane');
	  selbox.options[selbox.options.length] = new Option('traffic lights','at a set of traffic lights');
	  selbox.options[selbox.options.length] = new Option('junction','at a junction');
	  selbox.options[selbox.options.length] = new Option('round-about','at a round-about');
	  selbox.options[selbox.options.length] = new Option('mincunian way','on a mincunian way');
	  selbox.options[selbox.options.length] = new Option('motorway slip-road','on a motorway slip-road');
	  selbox.options[selbox.options.length] = new Option('motor way','on a motor way');
}

function carState()
{
	var selbox = document.frm.stat;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('stationary','stationary');
	selbox.options[selbox.options.length] = new Option('moving','moving');
	selbox.options[selbox.options.length] = new Option('parked','parked');
	selbox.options[selbox.options.length] = new Option('braking','braking');
	selbox.options[selbox.options.length] = new Option('slowing down','slowing down');
	selbox.options[selbox.options.length] = new Option('braking abruptly','braking abruptly');
}

function carImpact()
{
	var selbox = document.frm.impact;
	selbox.options.length=0;
	
	selbox.options[selbox.options.length] = new Option('front','front');
	selbox.options[selbox.options.length] = new Option('rear','rear');
	selbox.options[selbox.options.length] = new Option('left side','left side');
	selbox.options[selbox.options.length] = new Option('right side','right side');
	selbox.options[selbox.options.length] = new Option('not known','not known');
}

function carThrow()
{
	var selbox = document.frm.thr;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('sideways','sideways');
	selbox.options[selbox.options.length] = new Option('forward then backward','forward then backward');
	selbox.options[selbox.options.length] = new Option('backward then forward','backward then forward');
	selbox.options[selbox.options.length] = new Option('left side','left side');
	selbox.options[selbox.options.length] = new Option('right side','right side');
	selbox.options[selbox.options.length] = new Option('in all directions','in all directions');
}

function carDamage()
{
	var selbox = document.frm.dam;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('write-off','write-off');
	selbox.options[selbox.options.length] = new Option('extensive','cause extensive damage to');
	selbox.options[selbox.options.length] = new Option('moderate','cause moderate damage to');
	selbox.options[selbox.options.length] = new Option('mild','cause mild damage to');
	selbox.options[selbox.options.length] = new Option('unknown','unknown');
}

function carGotUp()
{
	var selbox = document.frm.gc;
	selbox.options.length=0;

	selbox.options[selbox.options.length] = new Option('---','');
	selbox.options[selbox.options.length] = new Option('got off the vahicle unaided','got off the vahicle unaided.');
	selbox.options[selbox.options.length] = new Option('needed help to get off the vahicle','needed help to get off the vahicle.');
}



function toway()
{
	if (document.getElementById('locat').value=='set of traffic lights' && document.getElementById('veh').value=='on foot' && document.getElementById('stat').value!='standing' && document.getElementById('stat').value!='crossing' && document.getElementById('stat').value!='waiting to cross')
	{
		alert('123');
		var selbox = document.frm.stat2;
		selbox.options.length=0;
	
		selbox.options[selbox.options.length] = new Option('towards','towards');
		selbox.options[selbox.options.length] = new Option('away from','away from');
	}
	else
	{
		var selbox = document.frm.stat2;
		selbox.options.length=0;
	}
}


function onatdoc()
{
	st=document.getElementById('stat').value;
	lo=document.getElementById('locat').value;
	
	var prov='';
	
	if (st=='standing' && lo!='set of traffic lights')
	{
		prov='on';
	}
	else if (st=='standing' && lo=='set of traffic lights')
	{
		prov='at';
	}
	else if (st!='standing' && lo=='set of traffic lights')
	{
		prov=document.getElementById('stat2').value;
	}
	else if (st=='crossing' && lo=='set of traffic lights')
	{
		prov='from';
	}
	else if (st=='waiting to cross' && lo=='set of traffic lights')
	{
		prov='at';
	}
	
	return prov;
}


function submiter()
{
	document.getElementById('accident2').value=document.getElementById('accident').innerHTML;
	
//	document.frm.submit();
}
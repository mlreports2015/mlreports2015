<?php

session_start();

include "inc.php";


if (!isset($_SESSION['id']))
{
	rdrctr("Login Details Incorrect","index.html");
}
else
{
	include 'dcon.php';
?>
<HEAD>
<TITLE>MLR Case</TITLE>

<SCRIPT language='JavaScript' type='text/javascript' src='Scripts/index.js'></SCRIPT>

<link href="CSS/calender.css" rel="stylesheet" type="text/css">
<script language="javaScript" type="text/javascript" src="Scripts/calender_date_picker.js"></script>

<?
echo "<link href=\"CSS/pmh.css\" rel=\"stylesheet\" type=\"text/css\">
	<script language=\"javaScript\" type=\"text/javascript\" src=\"Scripts/summary.js\"></script>
	<link href=\"CSS/calender.css\" rel=\"stylesheet\" type=\"text/css\">
	<script language=\"javaScript\" type=\"text/javascript\" src=\"Scripts/calender_date_picker.js\"></script>";
?>

</HEAD>

<BODY background="images/back.png" onload="init('d','de');">

<? $id= $_GET['cid']; ?>

<DIV style="background-image : url('images/fe.png'); background-repeat : no-repeat; width:1024px; float:right;">
<IMG align="middle" src="images/title3.png" />
<IMG align="middle" src="images/sum.png" style="margin-left : 700px;" />
</DIV>

<DIV style="float:right;right:20px;width:100%;">
<A href=home.php>Home</A> |
<A href=search.php>All Cases</A> |
<A href=search.php>General Search</A> |
<A href=search.php>Incomplete Cases</A> |
<A href=search.php>Complete Cases</A> |
</DIV>

<br />
<br />
<br />
<br />
<br />
<br />

<CENTER><H1><? echo "ML".$id;?></H1></CENTER>

<CENTER>
<DIV align="center">

<A href="det.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Details</A> | 

<A href="pmh.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">PMH</A> | 

<A href="accid.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Accident</A> | 

<A href="effect.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Symptoms</A> | 

<A href="treat.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Treatment</A> | 

<A href="life.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Life</A> | 

<A href="exam.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>"> Examination </A> | 

<A href="summary.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Summary</A> | 

<A href="prog.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Prognosis </A> | 

<A href="repgen.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Report</A>

<Div style="width:100%"></DIV>
</A>
</CENTER>



<FORM method="POST" action="Process/summary.php">

<input type="hidden" value="<? $id= $_GET['cid']; echo $id;?>" name="id" />

<?
$org=$_SESSION['o'];
  $q=mysql_query("select * from claimant where cid=$id and org='$org'");
  $r=mysql_fetch_array($q);
  $g=$r['gen'];
  
  if ($g=='m')
  {
  $g1='His';
  $g2='his';
  $g='He';
  $g3='he';
  }
  else
  {
  $g1='Her';
  $g2='her';
  $g='She';
  $g3='she';
  }
  
  $n=$r['ct']." ".$r['cln'];
  
  
?>

<CENTER><H1>Summary</H1></CENTER>

<DIV align="center">

<H3>Summary Impression</H3>

<TABLE align="center" border="1">
	<TR>
		<TD align="center" colspan="2">
			<SELECT name="hist">
				<OPTION value="I was able to obtain a good history.">I was able to obtain a good history</OPTION>
				<OPTION value="I was unable to obtain a good history.">I was unable to obtain a good history</OPTION>
			</SELECT>
		</TD>
	</TR>
	<TR>
		<TD>Were his injusries consistent with the account of the accident</TD>
		<TD>
			<SELECT name="inj">consistent with the account of the accident
				<OPTION value="<? echo $n; ?>'s injuries were entirely consistent with the account of the accident">Yes</OPTION>
				<OPTION value="<? echo $n; ?> injuries were not consistent with the account of the accident">No</OPTION>
				<OPTION value="<? echo $n; ?> injuries were mainly consistent with the account of the accident">Mainly</OPTION>
				<OPTION value="<? echo $n; ?> injuries were almost consistent with the account of the accident">Almost</OPTION>
			</SELECT>
		</TD>
	</TR>
	
	<TR>
		<TD>Treatment</TD>
		<TD>
			<SELECT name="treat">
				<OPTION value="<? echo $g1; ?> treatment has been appropriate. ">Appropriate</OPTION>
				<OPTION value="<? echo $g1; ?> treatment has not been appropriate. ">Inappropriate</OPTION>
			</SELECT>
		</TD>
	</TR>
	
	<TR>
		<TD>Problems in home life</TD>
		<TD>
			<SELECT name="hlyf">
				<OPTION value="The claimed problems in <?echo $n?>'s home life are consistent and reasonable.">Reasonable</OPTION>
				<OPTION value="The claimed problems in <?echo $n?>'s home life are inconsistent and unreasonable.">Reasonable</OPTION>
			</SELECT>
		</TD>
	</TR>
</TABLE>

<H3>Job Prospects</H3>

<TABLE align="center" border="1" width=700px>
	<TR>
		<TD align="center">
			<?echo $n;?> is currently
			<SELECT id="jrest" name="jrest" onclick="notres('<?php echo $g?>');">
				<OPTION value="<?echo $g;?> is fit to work.">fit to</OPTION>
				<OPTION value="<?echo $g;?> is mildly restricted at work.">mildly restricted at</OPTION>
				<OPTION value="<?echo $g;?> can only manage sedentary work.">only able to manage sedentary</OPTION>
			</SELECT>
			work.
			<DIV align="center" id="jab" onclick="notres2();" style="visibility:hidden;">
				<SELECT name="jabs" id="jabs">
					<OPTION value=".">...</OPTION>
					<OPTION value="<? echo $g1;?> ability to work is likely to improve steadily.">Would Steadily Improve</OPTION>
					<OPTION value="<? echo $g;?> might never be able to manage work properly.">Might Never improve</OPTION>
					<OPTION value="<? echo $g1;?> ability to work would return to normal.">Would Return to Normal</OPTION>
				</SELECT>
				
				<DIV align="center" id="jaba" style="visibility:hidden;">
					
					<TABLE align="center">
						<TR><TD align="center">
							<INPUT type="text" size="3" id="mpas" name="mpas" />
							<SELECT name="mmpast" id="mmpast">
								<OPTION value="day">days</OPTION>
								<OPTION value="week">weeks</OPTION>
								<OPTION value="month">months</OPTION>
								<OPTION value="year">years</OPTION>
							</SELECT>
						</TD></TR>
					</TABLE>
				</DIV>
			</DIV>
			<SELECT name="ltef" id="ltef">
				<OPTION value="In the long term, <?php echo $g2; ?> employment prospects on the open job market are likely to be unaffected.">In the long term, <?php echo $g2; ?> employment prospects on the open job market are likely to be unaffected.</OPTION>
				<OPTION value="In the long term, <?php echo $g2; ?> employment prospects on the open job market would be mildly restricted.">In the long term, <?php echo $g2; ?> employment prospects on the open job market would be mildly restricted.</OPTION>
				<OPTION value="In the long term, <?php echo $g2; ?> employment prospects would be moderately affected on the open job market.">In the long term, <?php echo $g2; ?> employment prospects would be moderately affected on the open job market.</OPTION>
				<OPTION value="In the long term, <?php echo $g3; ?> would be severely hindered on the open job market.">In the long term, <?php echo $g3; ?> would be severely hindered on the open job market.</OPTION>
			</SELECT>
				<br />
		</TD>
	</TR>
</TABLE>

<INPUT type="submit" value="Submit">

</DIV>

</FORM>

</BODY>

</HTML>

<?
}
?>
<!--Mr. XYZ is currently  work.
His ability to work is likely to return to normal over the next 4 months.


Mr. XYZ is currently  work.
His ability to work is likely to improve steadily.
In the long term, his employment prospects are likely to be unaffected.-->




<?php

include 'template.php';

head('Search','','','','','');


?>


<div align="center" id="search" style="position:relative; top:200px;">
<form action="Process/search.php" method="POST">
<table width="100%;" align="center">
<tr>
<td>First Name</td>
<td><input type="text" name="fn" /></td>
<td>Last Name</td>
<td><input type="text" name="ln" /></td>
</tr>
<tr>
<td>Solicitor Reference</td>
<td><input type="text" name="sr" /></td>
<td>Agency Reference</td>
<td><input type="text" name="ar" /></td>
</tr>
<tr><td colspan="4" align="center"><input type="submit" value="Search" /></td></tr>
</table>
</form>
</div>

</Body>
</HTML>


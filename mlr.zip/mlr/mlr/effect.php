<?php

include 'template.php';

head('Symptoms', '<link href="CSS/eff.css" rel="stylesheet" type="text/css">', '<script language="javaScript" type="text/javascript" src="Scripts/eff.js"></script>', '', '', '');
?>

<BODY background="images/back.png" onLoad="doeF();">


<?php

include 'template2.php';

$id=$_GET['cid'];

$org=$_SESSION['o'];

bTop('Symptoms', $org, $id);

?>

<FORM method="POST" action="Process/eff.php" name="eff">

<?php 

$si="select * from eff where id='$id' and org='".$_SESSION['o']."' and tp='l'  and msg='Does not report any initial symptoms.'";
$qi=mysql_query($si);
$qqi=mysql_num_rows($qi)-1;

//$pmp=0;

if ($qqi==-1)
{
	$si="select * from eff where id='$id' and org='".$_SESSION['o']."' and tp='l'";
	$qi=mysql_query($si);
	$qqi=mysql_num_rows($qi);
	
	if ($qqi==-1)
		$qqi=0;
	
//	$pmp=1;
	
//	echo "here";
}

$sl="select * from eff where id='$id' and org='".$_SESSION['o']."' and tp='i' and msg='Does not report any later symptoms.'";
$ql=mysql_query($sl);
$qql=mysql_num_rows($ql)-1;

//$pmp=0;

if ($qql==-1)
{
	$sl="select * from eff where id='$id' and org='".$_SESSION['o']."' and tp='i'";
	$ql=mysql_query($sl);
	$qql=mysql_num_rows($ql);
	
	if ($qql==-1)
		$qql=0;
	
//	$pmp=1;
	
//	echo "here";
}

?>

<input type="hidden" value="<?php echo $qqi;?>" name="tv" id="theValue" />
<input type="hidden" value="<?php echo $qql;?>" name="tv2" id="theValue2" />

<input type="hidden" value="<? echo $_GET['cid'];?>" name="id" />


<DIV align="left" id="sh">
	<CENTER><H3>Shock</H3></CENTER>
	<TABLE border="1" align="center">
		<TR>
			
			<TD>
				<SELECT>
					<OPTION value="i">Initial Symptom</OPTION>
				</SELECT>
			</TD>
			<TD>Suffered</TD>
			<TD>
				<SELECT name="shlev" id="shlev">
					<OPTION value="mild">mild</OPTION>
					<OPTION value="moderate" selected="selected">moderate</OPTION>
					<OPTION value="severe">severe</OPTION>
				</SELECT>
			</TD>

			<td>
				<select name="shck" id="shck">
					<option value="shock">Shock</option>
					<option value="crying">Crying</option>
					<option value="diziness">Diziness</option>
				</select>
			</td>
			
			<TD>
				<SELECT name="sre" id="sre" onclick="notres('sres','snres','sre');">
					<OPTION value="resolved after">resolved after</option>
					<OPTION value="has not resolved">has not resolved</OPTION>
				</SELECT>
				<DIV id="sres">
					<INPUT type="text" size="5" name="sress" value="1" id="sress"> 
						<SELECT name="sresa" id="sresa">
							<OPTION value="day">days</OPTION>
							<OPTION value="week">weeks</OPTION>
							<OPTION value="month">months</OPTION>
							<OPTION value="year">years</OPTION>
						</SELECT>
					</DIV>
					<DIV id="snres" style="visibility:hidden;">
						causing 
						<SELECT name="srdis" id="srdis">
							<OPTION value="mild">mild</OPTION>
							<OPTION value="moderate">moderate</OPTION>
							<OPTION value="severe">severe</OPTION>
						</SELECT> 
						disability
					</DIV>
				</TD>
			</TR>
			
			<TR>
				<TD colspan="6" align="center"><INPUT type="button" onClick="addshock();" value="Add"></TD>
				</TR>
			</TABLE>
</DIV>

<DIV id=shk> </DIV>



<DIV align="left" id="shh">
	<CENTER><H3>Pain</H3></CENTER>
	<TABLE border="1" align="center">
		<TR>
			<TD>
				<SELECT id="il" onclick="if (document.getElementById('il').value=='l')document.getElementById('latetm').style.visibility='visible'; else document.getElementById('latetm').style.visibility='hidden';">
					<OPTION value="i">Initial Symptom</OPTION>
					<OPTION value="l">Later Symptom</OPTION>
				</SELECT>
				<DIV id="latetm" style="visibility:hidden;">
					Developed symptom after
					<INPUT type="text" id="ltme" />
					<SELECT name="ltmh" id="ltmh">
						<OPTION value="hour">hours</OPTION>
						<OPTION selected="selected" value="day">days</OPTION>
						<OPTION value="week">weeks</OPTION>
					</SELECT>
				</DIV>
				<INPUT id="iib" type="button" value="" onClick="stiff();" />Stiffness<INPUT id="iii" type="hidden" value="0" />
			</TD>
			<TD>Suffered</TD>
			<TD>
				<SELECT name="hlev" id="hlev">
					<OPTION value="mild">mild</OPTION>
					<OPTION value="moderate">moderate</OPTION>
					<OPTION value="severe">severe</OPTION>
				</SELECT>
			</TD>
			
			<TD>
				<SELECT name="prob" id="prob">
					<OPTION value="headache">head</OPTION>
                    <OPTION value="neck pain">neck</OPTION>
                    <OPTION value="back pain">back</OPTION>
                    <OPTION value="shoulders pain">shoulders</OPTION>
                    <OPTION value="neck and shoulders pain">neck and shoulders</OPTION>
                    <option value="ears pain">ears</option>
                    <option value="left ear pain">left ear</option>
                    <option value="right ear pain">right ear</option>
                    <OPTION value="forehead pain">forehead</OPTION>
                    <OPTION value="left temple pain">left temple</OPTION>
                    <OPTION value="right temple pain">right temple</OPTION>
                    <OPTION value="temples pain">temples</OPTION>
                    <OPTION value="left eye pain">left eye</OPTION>
                    <OPTION value="right eye pain">right eye</OPTION>
                    <OPTION value="eyes pain">eyes</OPTION>
                    <option value="nose pain">nose</option>
                    <option value="nose bridge pain">nose bridge</option>
                    <OPTION value="left nostril pain">left nostril pain</OPTION>
                    <OPTION value="right nostril pain">right nostril</OPTION>
                    <OPTION value="nostrils pain">nostrils pain</OPTION>
                    <option value="cheeks pain">cheeks</option>
                    <option value="left cheek pain">left cheek</option>
                    <option value="right cheek pain">right cheek</option>
                    <option value="jaw pain">jaw</option>
                    <option value="jaw bone pain">jaw bone</option>
                    <option value="upper jaw pain">upper jaw</option>
                    <option value="lower jaw pain">lower jaw</option>
                    <option value="lips pain">lips</option>
                    <OPTION value="upper lip pain">upper lip</OPTION>
                    <OPTION value="lower lip pain">lower lip</OPTION>
                    <option value="teeth pain">teeth</option>
                    <option value="incisors pain">incisors</option>
                    <option value="premolar pain">premolar</option>
                    <option value="molars pain">molars</option>
                    <option value="tongue pain">tongue</option>
                    <option value="chin pain">chin</option>
                    <OPTION value="upper back pain">upper back</OPTION>
					<OPTION value="lower back pain">lower back</OPTION>
                    <OPTION value="cervical spine pain">cervical spine</OPTION>
                    <OPTION value="thoratic pain">thoratic</OPTION>
                    <OPTION value="lumbar spine pain">lumbar spine</OPTION>
                    <option value="sacrum spine pain">sacrum spine</option>
                    <option value="inter-vertebrael disc pain">inter-vertebrael disc</option>
                    <OPTION value="left shoulder pain">left shoulder</OPTION>
                    <OPTION value="right shoulder pain">right shoulder</OPTION>
                    <OPTION value="armpit pain">armpit</OPTION>
                    <OPTION value="left armpit pain">left armpit</OPTION>
                    <OPTION value="right armpit pain">right armpit</OPTION>
                    <option value="shoulder blades pain">shoulder blades</option>
                    <option value="left shoulder blade pain">left shoulder blade</option>
                    <option value="right shoulder blade pain">right shoulder blade</option>
					<OPTION value="left shoulder pain">left shoulder</OPTION>
					<OPTION value="right shoulder pain">right shoulder</OPTION>
                    <OPTION value="coracoid process pain">coracoid process</OPTION>
                    <OPTION value="clavicle pain">clavicle</OPTION>
                    <OPTION value="AC joint pain">AC joint</OPTION>
                    <OPTION value="acromion pain">acromion</OPTION>
					<OPTION value="arms pain">arms</OPTION>
					<OPTION value="left arm pain">left arm</OPTION>
					<OPTION value="right arm pain">right arm</OPTION>
                    <OPTION value="biceps pain">biceps</OPTION>
					<OPTION value="left bicep pain">left bicep</OPTION>
					<OPTION value="right bicep pain">right bicep</OPTION>
                    <OPTION value="triceps pain">triceps</OPTION>
					<OPTION value="left tricep pain">left tricep</OPTION>
					<OPTION value="right tricep pain">right tricep</OPTION>
                    <OPTION value="wrists pain">wrists</OPTION>
					<OPTION value="left wrist pain">left wrist</OPTION>
					<OPTION value="right wrist pain">right wrist</OPTION>
                    <OPTION value="hands pain">hands</OPTION>
					<OPTION value="left hand pain">left hand</OPTION>
					<OPTION value="right hand pain">right hand</OPTION>
                    <OPTION value="palms pain">palms</OPTION>
                    <OPTION value="left palm pain">left palm</OPTION>
                    <OPTION value="right palm pain">right palm</OPTION>
                    <OPTION value="knuckles pain">knuckles</OPTION>
                    <OPTION value="left knuckle pain">left knuckle</OPTION>
                    <OPTION value="right knuckle pain">right knuckle</OPTION>
                    <option value="fingers pain">fingers pain</option>
                    <option value="left hand fingers pain">left hand fingers</option>
                    <option value="right hand fingers pain">right hand fingers pain</option>
                    <option value="finger nails pain">finger nails pain</option>
                    <option value="left-hand finger nails pain">left-hand finger nails pain</option>
                    <option value="right-hand finger nails pain">right-hand finger nails pain</option>
					<OPTION value="chest pain">chest</OPTION>
                    <OPTION value="pectoral pain">pectoral</OPTION>
                    <OPTION value="trapezius pain">trapezius</OPTION>
                    <OPTION value="scapula pain">scapula</OPTION>
                    <OPTION value="sternum pain">sternum</OPTION>
                    <OPTION value="spinal pain">spine</OPTION>
                    <OPTION value="collarbone pain">collarbone</OPTION>
                    <OPTION value="ribs pain">ribs</OPTION>
                    <option value="breasts pain">breasts</option>
                    <option value="left breast pain">left breast</option>
                    <option value="right breast pain">right breast</option>
                    <option value="areola pain">areola</option>
                    <option value="nipples pain">nipples</option>
                    <option value="left nipple pain">left nipple</option>
                    <option value="right nipple pain">right nipple</option>
                    <OPTION value="abdomen pain">abdomen</OPTION>
                    <option value="navel pain">navel</option>
                    <OPTION value="(abdominal) right upper quadrant pain">(abdominal) right upper quadrant</OPTION>
                    <OPTION value="(abdominal) left upper quadrant pain">(abdominal) left upper quadrant</OPTION>
                    <OPTION value="(abdominal) right lower quadrant pain">(abdominal) right lower quadrant</OPTION>
                    <OPTION value="(abdominal) left lower quadrant pain">(abdominal) left lower quadrant</OPTION>
                    <OPTION value="genitalia pain">genitalia</OPTION>
                    <OPTION value="penis pain">penis</OPTION>
                    <OPTION value="scrotum pain">scrotum</OPTION>
                    <OPTION value="mons pubis pain">mons pubis</OPTION>
                    <OPTION value="cleft of venus pain">cleft of venus</OPTION>
                    <OPTION value="hips pain">hips</OPTION>
                    <OPTION value="left hip pain">left hip</OPTION>
                    <OPTION value="right hip pain">right hip</OPTION>
					<OPTION value="legs pain">legs</OPTION>
					<OPTION value="left leg pain">left leg</OPTION>
					<OPTION value="right leg pain">right leg</OPTION>
					<OPTION value="knees pain">knees</OPTION>
                    <OPTION value="left knee pain">left knee</OPTION>
					<OPTION value="right knee pain">right knee</OPTION>
                    <OPTION value="shin pain">shins</OPTION>
                    <OPTION value="left shin pain">left shin</OPTION>
                    <OPTION value="right shin pain">right shin</OPTION>
                    <OPTION value="calves pain">calves</OPTION>
                    <OPTION value="left calf pain">left calf</OPTION>
                    <OPTION value="right calf pain">right calf</OPTION>
                    <OPTION value="ankles pain">ankles</OPTION>
					<OPTION value="left ankle pain">left ankle</OPTION>
					<OPTION value="right ankle pain">right ankle</OPTION>
                    <OPTION value="feet pain">feet</OPTION>
					<OPTION value="left foot pain">left foot</OPTION>
					<OPTION value="right foot pain">right foot</OPTION>
                    <OPTION value="heels pain">heels</OPTION>
                    <OPTION value="left heel pain">left heel</OPTION>
                    <OPTION value="right heel pain">right heel</OPTION>
                    <OPTION value="foot soles pain">foot soles</OPTION>
                    <OPTION value="left foot sole pain">left foot sole</OPTION>
                    <OPTION value="right foot sole pain">right foot sole</OPTION>
                    <OPTION value="(feet) balls pain">(feet) balls</OPTION>
                    <OPTION value="(feet) left ball pain">(feet) left ball</OPTION>
                    <OPTION value="(feet) right ball pain">(feet) right ball</OPTION>
                    <OPTION value="toes pain">toes</OPTION>
                    <OPTION value="left foot toes pain">left foot toes</OPTION>
                    <OPTION value="right foot toes pain">right foot toes</OPTION>
                    <OPTION value="toe nails pain">toe nails</OPTION>
                    <OPTION value="left toe nails pain">left toe nails</OPTION>
                    <OPTION value="right toe nails pain">right toe nails</OPTION>
					<OPTION value="anxiety">anxiety</OPTION>
					<OPTION value="nightmares">nightmares</OPTION>
					<OPTION value="depression">depression</OPTION>
					<OPTION value="enuresis">enuresis</OPTION>
					<OPTION value="social-wthdrawal">social-wthdrawal</OPTION>
					<OPTION value="panic-attacks">panic-attacks</OPTION>
                    <OPTION value="post-traumatic stress disorder">post-traumatic stress disorder</OPTION>
                    <OPTION value="obsessive-Compulsive Disorder">obsessive-Compulsive Disorder</OPTION>
                    <OPTION value="agoraphobia">agoraphobia</OPTION>
                    <OPTION value="generalized anxiety disorder">generalized anxiety disorder</OPTION>
                    <OPTION value="mood disorder">mood disorder</OPTION>
                    <OPTION value="clinical depression">clinical depression</OPTION>
                    <OPTION value="psychotic disorders">psychotic disorders</OPTION>
                    <OPTION value="obsessive�compulsive disorder">obsessive�compulsive disorder</OPTION>
                    <OPTION value="paranoid personality disorder">paranoid personality disorder</OPTION>
				</SELECT>
			</TD>
			
			<TD>
				<SELECT name="re" id="re" onclick="notres('res','pres','re');">
					<OPTION value="resolved after">resolved after</OPTION>
					<OPTION selected="selected" value="has not resolved">has not resolved</OPTION>
				</SELECT>
				<DIV id="res" style="visibility:hidden;">
					<INPUT type="text" size="5" name="ress" id="ress"> 
					<SELECT name="resa" id="resa">
						<OPTION value="day">days</OPTION>
						<OPTION value="week">weeks</OPTION>
						<OPTION value="month">months</OPTION>
						<OPTION value="year">years</OPTION>
					</SELECT>
caused by
<SELECT name="cause" id="cause" onclick="secon();">
	<option value=".">Unknown</option>
	<OPTION selected="selected" value="a whiplash injury">Whiplash</OPTION>
	<OPTION value="an exacerbation of a pre-existing condition">exacerbation of a pre-existing condition</OPTION>
	<OPTION value="a trauma from the seatbelt">from the seatbelt</OPTION>
    <OPTION value="a direct trauma">direct trauma</OPTION>
	<OPTION value="a sprain sustained in the accident">sprain sustained in the accident</OPTION>
	<OPTION value="secondary to">secondary to (select from the next list)</OPTION>
    <option value="stress of accident">stress of accident</option>
    <option value="broken windscreen">broken windscreen</option>
    <option value="broken window">broken window</option>
    <option value="air-bag deploying">air-bag deploying</option>
    <option value="loose object in car">loose object in car</option>
    <option value="hitting steering wheel">hitting steering wheel</option>
    <option value="getting hand stuck between objects">getting hand caught between objects</option>
    <option value="vehicle overturning">vehicle overturning</option>
    <option value="falling off the bike">falling off the bike</option>
    <option value="getting hit by other passenger(s)">getting hit by other passenger(s)</option>
    <option value="a fall">a fall</option>
    <option value="being over-worked">being over-worked</option>
    <option value="slipping at work">slipping at work</option>
    <option value="medical negligence">medical negligence</option>
    <option value="lifting a heavy item">lifting a heavy item</option>
    <option value="sports">sports</option>
</SELECT>

<div id="dsec" style="visibility:hidden;">
<SELECT name="cause2" id="cause2">
	<OPTION value="head ache">head ache</OPTION>
	<OPTION value="neck pain">neck pain</OPTION>
	<OPTION value="back pain">back pain</OPTION>
	<OPTION value="lower back pain">lower back pain</OPTION>
	<OPTION value="upper back pain">upper back pain</OPTION>
	<OPTION value="shoulder pain">shoulder pain</OPTION>
	<OPTION value="left shoulder pain">left shoulder pain</OPTION>
	<OPTION value="right shoulder pain">right shoulder pain</OPTION>
	<OPTION value="arm pain">arm pain</OPTION>
	<OPTION value="left arm pain">left arm pain</OPTION>
	<OPTION value="right arm pain">right arm pain</OPTION>
	<OPTION value="chest pain">chest pain</OPTION>
	<OPTION value="stomach pain">stomach pain</OPTION>
	<OPTION value="legs pain">legs pain</OPTION>
	<OPTION value="left leg pain">left leg pain</OPTION>
	<OPTION value="right leg pain">right leg pain</OPTION>
</SELECT>
</div>
				</DIV>
				<DIV id="pres" style="visibility:visible;">
					causing 
					<SELECT name="rdis" id="rdis">
						<OPTION value="mild">mild</OPTION>
						<OPTION selected="selected" value="mild and occasional">mild and occasional</OPTION>
						<OPTION value="mild to moderate">mild to moderate</OPTION>
						<OPTION value="moderate">moderate</OPTION>
						<OPTION value="severe">severe</OPTION>
						<OPTION value="persisting">persisting</OPTION>
					</SELECT> 
					disability
				</DIV>
			</TD>
		</TR>
			
		<TR>
			<TD colspan="6" align="center"><INPUT type="button" onClick="addpain();" value="Add"></TD>
		</TR>
	</TABLE>
</DIV>

<DIV id="pn"> </DIV>



<DIV align="left" id="shh">
	<CENTER><H3>Bruising/Burn/Laceration/Grazing/Ligaments/Tendons</H3></CENTER>
	<TABLE border="1" align="center">
		<TR>
			<TD>
				<SELECT id="bil">
					<OPTION value="burns">Burn</OPTION>
					<OPTION value="bruising">Bruising</OPTION>
					<OPTION value="grazing">Grazing</OPTION>
					<OPTION value="laceration">Laceration</OPTION>
                    <option value="swelling">swelling</option>
                    <option value="torn ligaments">torn ligaments</option>
                    <option value="torn tendons">torn tendons</option>
				</SELECT>
			</TD>
			<TD>Suffered</TD>
			<TD>
				<SELECT name="bhlev" id="bhlev">
					<OPTION value="mild">mild</OPTION>
					<OPTION value="moderate">moderate</OPTION>
					<OPTION value="severe">severe</OPTION>
				</SELECT>
			</TD>
			
			<TD>
				<SELECT name="bprob" id="bprob">
					<OPTION value="head">head</OPTION>
                    <option value="ears">ears</option>
                    <option value="left ear">left ear</option>
                    <option value="right ear">right ear</option>
                    <OPTION value="forehead">forehead</OPTION>
                    <OPTION value="left temple">left temple</OPTION>
                    <OPTION value="right temple">right temple</OPTION>
                    <OPTION value="temples">temples</OPTION>
                    <OPTION value="left eye">left eye</OPTION>
                    <OPTION value="right eye">right eye</OPTION>
                    <OPTION value="eyes">eyes</OPTION>
                    <option value="nose">nose</option>
                    <option value="nose bridge">nose bridge</option>
                    <OPTION value="left nostril">left nostril pain</OPTION>
                    <OPTION value="right nostril">right nostril</OPTION>
                    <OPTION value="nostrils">nostrils pain</OPTION>
                    <option value="cheeks">cheeks</option>
                    <option value="left cheek">left cheek</option>
                    <option value="right cheek">right cheek</option>
                    <option value="jaw">jaw</option>
                    <option value="jaw bone">jaw bone</option>
                    <option value="upper jaw">upper jaw</option>
                    <option value="lower jaw">lower jaw</option>
                    <option value="lips">lips</option>
                    <OPTION value="upper lip">upper lip</OPTION>
                    <OPTION value="lower lip">lower lip</OPTION>
                    <option value="teeth">teeth</option>
                    <option value="incisors">incisors</option>
                    <option value="premolar">premolar</option>
                    <option value="molars">molars</option>
                    <option value="tongue">tongue</option>
                    <option value="chin">chin</option>
					<OPTION value="neck">neck</OPTION>
					<OPTION value="back">back</OPTION>
                    <OPTION value="upper back">upper back</OPTION>
					<OPTION value="lower back">lower back</OPTION>
                    <OPTION value="cervical spine">cervical spine</OPTION>
                    <OPTION value="thoratic">thoratic</OPTION>
                    <OPTION value="lumbar spine">lumbar spine</OPTION>
                    <option value="sacrum spine">sacrum spine</option>
                    <option value="inter-vertebrael disc">inter-vertebrael disc</option>
					<OPTION value="shoulders">shoulders</OPTION>
                    <OPTION value="left shoulder">left shoulder</OPTION>
                    <OPTION value="right shoulder">right shoulder</OPTION>
                    <OPTION value="armpit">armpit</OPTION>
                    <OPTION value="left armpit">left armpit</OPTION>
                    <OPTION value="right armpit">right armpit</OPTION>
					<OPTION value="neck and shoulders">neck and shoulders</OPTION>
                    <option value="shoulder blades">shoulder blades</option>
                    <option value="left shoulder blade">left shoulder blade</option>
                    <option value="right shoulder blade">right shoulder blade</option>
					<OPTION value="left shoulder">left shoulder</OPTION>
					<OPTION value="right shoulder">right shoulder</OPTION>
                    <OPTION value="coracoid process">coracoid process</OPTION>
                    <OPTION value="clavicle">clavicle</OPTION>
                    <OPTION value="AC joint">AC joint</OPTION>
                    <OPTION value="acromion">acromion</OPTION>
					<OPTION value="arms">arms</OPTION>
					<OPTION value="left arm">left arm</OPTION>

					<OPTION value="right arm">right arm</OPTION>
                    <OPTION value="biceps">biceps</OPTION>
					<OPTION value="left bicep">left bicep</OPTION>
					<OPTION value="right bicep">right bicep</OPTION>
                    <OPTION value="triceps">triceps</OPTION>
					<OPTION value="left tricep">left tricep</OPTION>
					<OPTION value="right tricep">right tricep</OPTION>
                    <OPTION value="wrists">wrists</OPTION>
					<OPTION value="left wrist">left wrist</OPTION>
					<OPTION value="right wrist">right wrist</OPTION>
                    <OPTION value="hands">hands</OPTION>
					<OPTION value="left hand">left hand</OPTION>
					<OPTION value="right hand">right hand</OPTION>
                    <OPTION value="palms">palms</OPTION>
                    <OPTION value="left palm">left palm</OPTION>
                    <OPTION value="right palm">right palm</OPTION>
                    <OPTION value="knuckles">knuckles</OPTION>
                    <OPTION value="left knuckle">left knuckle</OPTION>
                    <OPTION value="right knuckle">right knuckle</OPTION>
                    <option value="fingers">fingers pain</option>
                    <option value="left hand fingers">left hand fingers</option>
                    <option value="right hand fingers">right hand fingers pain</option>
                    <option value="finger nails">finger nails pain</option>
                    <option value="left-hand finger nails">left-hand finger nails pain</option>
                    <option value="right-hand finger nails">right-hand finger nails pain</option>
					<OPTION value="chest">chest</OPTION>
                    <OPTION value="pectoral">pectoral</OPTION>
                    <OPTION value="trapezius">trapezius</OPTION>
                    <OPTION value="scapula">scapula</OPTION>
                    <OPTION value="sternum">sternum</OPTION>
                    <OPTION value="spinal">spine</OPTION>
                    <OPTION value="collarbone">collarbone</OPTION>
                    <OPTION value="ribs">ribs</OPTION>
                    <option value="breasts">breasts</option>
                    <option value="left breast">left breast</option>
                    <option value="right breast">right breast</option>
                    <option value="areola">areola</option>
                    <option value="nipples">nipples</option>
                    <option value="left nipple">left nipple</option>
                    <option value="right nipple">right nipple</option>
                    <OPTION value="abdomen">abdomen</OPTION>
                    <option value="navel">navel</option>
                    <OPTION value="(abdominal) right upper quadrant">(abdominal) right upper quadrant</OPTION>
                    <OPTION value="(abdominal) left upper quadrant">(abdominal) left upper quadrant</OPTION>
                    <OPTION value="(abdominal) right lower quadrant">(abdominal) right lower quadrant</OPTION>
                    <OPTION value="(abdominal) left lower quadrant">(abdominal) left lower quadrant</OPTION>
                    <OPTION value="genitalia">genitalia</OPTION>
                    <OPTION value="penis">penis</OPTION>
                    <OPTION value="scrotum">scrotum</OPTION>
                    <OPTION value="mons pubis">mons pubis</OPTION>
                    <OPTION value="cleft of venus">cleft of venus</OPTION>
                    <OPTION value="hips">hips</OPTION>
                    <OPTION value="left hip">left hip</OPTION>
                    <OPTION value="right hip">right hip</OPTION>
					<OPTION value="legs">legs</OPTION>
					<OPTION value="left leg">left leg</OPTION>
					<OPTION value="right leg">right leg</OPTION>
					<OPTION value="knees">knees</OPTION>
                    <OPTION value="left knee">left knee</OPTION>
					<OPTION value="right knee">right knee</OPTION>
                    <OPTION value="shin">shins</OPTION>
                    <OPTION value="left shin">left shin</OPTION>
                    <OPTION value="right shin">right shin</OPTION>
                    <OPTION value="calves">calves</OPTION>
                    <OPTION value="left calf">left calf</OPTION>
                    <OPTION value="right calf">right calf</OPTION>
                    <OPTION value="ankles">ankles</OPTION>
					<OPTION value="left ankle">left ankle</OPTION>
					<OPTION value="right ankle">right ankle</OPTION>
                    <OPTION value="feet">feet</OPTION>
					<OPTION value="left foot">left foot</OPTION>
					<OPTION value="right foot">right foot</OPTION>
                    <OPTION value="heels">heels</OPTION>
                    <OPTION value="left heel">left heel</OPTION>
                    <OPTION value="right heel">right heel</OPTION>
                    <OPTION value="foot soles">foot soles</OPTION>
                    <OPTION value="left foot sole">left foot sole</OPTION>
                    <OPTION value="right foot sole">right foot sole</OPTION>
                    <OPTION value="(feet) balls">(feet) balls</OPTION>
                    <OPTION value="(feet) left ball">(feet) left ball</OPTION>
                    <OPTION value="(feet) right ball">(feet) right ball</OPTION>
                    <OPTION value="toes">toes</OPTION>
                    <OPTION value="left foot toes">left foot toes</OPTION>
                    <OPTION value="right foot toes">right foot toes</OPTION>
                    <OPTION value="toe nails">toe nails</OPTION>
                    <OPTION value="left toe nails">left toe nails</OPTION>
                    <OPTION value="right toe nails">right toe nails</OPTION>
				</SELECT>
			</TD>
			
			<TD>
				<SELECT name="bre" id="bre" onclick="notresBurn('bres','bbres','bre');">
                	<option value="">unknown</option>
					<OPTION value="resolved after">resolved</OPTION>
					<OPTION value="has not resolved">has not resolved</OPTION>
				</SELECT>
				<DIV id="bres" style="visibility:hidden;">
                	(optional) after
					<INPUT type="text" size="5" name="bress" id="bress"> 
						<SELECT name="bresa" id="bresa">
							<OPTION value="day">days</OPTION>
							<OPTION value="week">weeks</OPTION>
							<OPTION value="month">months</OPTION>
							<OPTION value="year">years</OPTION>
						</SELECT>
                        
caused by
<SELECT name="causeBurn" id="causeBurn" onclick="seconBurn();">
	<option value=".">Unknown</option>
	<OPTION selected="selected" value="a whiplash injury">Whiplash</OPTION>
	<OPTION value="an exacerbation of a pre-existing condition">exacerbation of a pre-existing condition</OPTION>
	<OPTION value="a trauma from the seatbelt">from the seatbelt</OPTION>
	<OPTION value="a sprain sustained in the accident">sprain sustained in the accident</OPTION>
	<OPTION value="secondary to">secondary to (select from the next list)</OPTION>
    <option value="stress of accident">stress of accident</option>
    <option value="broken windscreen">broken windscreen</option>
    <option value="broken window">broken window</option>
    <option value="air-bag deploying">air-bag deploying</option>
    <option value="loose object in car">loose object in car</option>
    <option value="hitting steering wheel">hitting steering wheel</option>
    <option value="getting hand stuck between objects">getting hand caught between objects</option>
    <option value="vehicle overturning">vehicle overturning</option>
    <option value="falling off the bike">falling off the bike</option>
    <option value="getting hit by other passenger(s)">getting hit by other passenger(s)</option>
    <option value="a fall">a fall</option>
    <option value="being over-worked">being over-worked</option>
    <option value="slipping at work">slipping at work</option>
    <option value="medical negligence">medical negligence</option>
    <option value="lifting a heavy item">lifting a heavy item</option>
    <option value="sports">sports</option>
</SELECT>

<div id="dsecBurn" style="visibility:hidden;">
<SELECT name="cause2Burn" id="cause2Burn">
	<OPTION value="head ache">head ache</OPTION>
	<OPTION value="neck pain">neck pain</OPTION>
	<OPTION value="back pain">back pain</OPTION>
	<OPTION value="lower back pain">lower back pain</OPTION>
	<OPTION value="upper back pain">upper back pain</OPTION>
	<OPTION value="shoulder pain">shoulder pain</OPTION>
	<OPTION value="left shoulder pain">left shoulder pain</OPTION>
	<OPTION value="right shoulder pain">right shoulder pain</OPTION>
	<OPTION value="arm pain">arm pain</OPTION>
	<OPTION value="left arm pain">left arm pain</OPTION>
	<OPTION value="right arm pain">right arm pain</OPTION>
	<OPTION value="chest pain">chest pain</OPTION>
	<OPTION value="stomach pain">stomach pain</OPTION>
	<OPTION value="legs pain">legs pain</OPTION>
	<OPTION value="left leg pain">left leg pain</OPTION>
	<OPTION value="right leg pain">right leg pain</OPTION>
</SELECT>
					</DIV>
                    
                    
                    
					<DIV id="bbres" style="visibility:hidden;">
						causing 
						<SELECT name="brdis" id="brdis">
							<OPTION value="mild">mild</OPTION>
							<OPTION value="mild and occasional">mild and occasional</OPTION>
							<OPTION value="mild to moderate">mild to moderate</OPTION>
							<OPTION value="moderate">moderate</OPTION>
							<OPTION value="severe">severe</OPTION>
						</SELECT> 
						disability
					</DIV>
				</TD>
			</TR>
			
			<TR>
				<TD colspan="6" align="center"><INPUT type="button" onClick="addbruise();" value="Add"></TD>
				</TR>
			</TABLE>
</DIV>

<DIV id="bru"> </DIV>



<DIV align="center" id="other">
	<CENTER><H3>Other</H3></CENTER>
	
	<SELECT id="oil">
		<OPTION value="i">Initial Symptom</OPTION>
		<OPTION value="l">Later Symptom</OPTION>
	</SELECT>
	
	<TEXTAREA name="oth" id="oth" cols="100" rows="5"></TEXTAREA>
	
	<SELECT id="ores">
		<OPTION value="resolved">Resolved</OPTION>
		<OPTION value="unresolved">Unresolved</OPTION>
	</SELECT>

	<INPUT type="button" onClick="addother();" value="Add">
</DIV>

<div id="myDiv" align="center" style="width:200px;"> </div>
<!-- <CENTER><INPUT type="button" value="Finalize" onclick="final();"></CENTER> -->

<?php 

$ii=1;
while ($ri=mysql_fetch_array($qi))
{
	echo "<input type='text' value='".$ri['stat']."' name='ih[$ii]' id='ih[$ii]' />";
	echo "<input type='text' value='".$ri['prob']."' name='ip[$ii]' id='ip[$ii]' />";
	echo "<textarea cols=100 rows=2 id='i[$ii]' name='i[$ii]'>".$ri['msg']."</textarea>";
	echo "<input type='hidden' value='Block' name='pphhi[$ii]' id='pphhi[$ii]' />";
	echo "<input type='button' style='background-color:#AA3333;color:#FFF;' onclick=\"ignorei('$ii');\" value='Block' id='pphhib[$ii]' name='pphhib[$ii]' /><br />";
	$ii=$ii+1;
}

$il=1;
while ($rl=mysql_fetch_array($ql))
{
	echo "<input type='text' value='".$rl['stat']."' name='lh[$il]' id='lh[$il]' />";
	echo "<input type='text' value='".$rl['prob']."' name='lp[$il]' id='lp[$il]' />";
	echo "<textarea cols=100 rows=2 id='l[$il]' name='l[$il]'>".$rl['msg']."</textarea>";
	echo "<input type='hidden' value='Block' name='pphhl[$il]' id='pphhl[$il]' />";
	echo "<input type='button' style='background-color:#AA3333;color:#FFF;' onclick=\"ignorel('$il');\" value='Block' id='pphhlb[$il]' name='pphhlb[$il]' /><br />";
	$il=$il+1;
}

?>

<CENTER><INPUT type="submit" value="Submit"></CENTER>

	
</FORM>

</BODY>

</HTML>

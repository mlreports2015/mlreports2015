<?php

include 'template.php';

head('Accident', '<link href="CSS/det.css" rel="stylesheet" type="text/css">', '<script language="javaScript" type="text/javascript" src="Scripts/accid.js"></script>', '', '', '');
?>

<BODY background="images/back.png" onLoad="doeF();">


<?php

include 'template2.php';

$id=$_GET['cid'];

$org=$_SESSION['o'];

bTop('Accident', $org, $id);

?>

<FORM action="Process/accid2.php" method="POST" name="frm" id="frm">

<INPUT type="hidden" value="<? echo $_GET['cid']; ?>" name="id">

<TABLE border="1" align="center" width="70%">

<?
$ss="select * from claimant where cid='$id' and org='".$_SESSION['o']."'";
// echo $ss;
$qq=mysql_query($ss);
$res=mysql_fetch_array($qq);

$sa="select * from accid where id='$id' and org='".$_SESSION['o']."'";
// echo $sa;
$qa=mysql_query($sa);
$ra=mysql_fetch_array($qa);

?>

<INPUT type="hidden" value="<? echo $res['ct']; ?>" id='tt' />
<INPUT type="hidden" value="<? echo $res['cln']; ?>" id='cln' />
<INPUT type="hidden" value="<? echo $res['gen']; ?>" id='gnd' />

<TR>
<TD>Time</TD>
<TD>
<SELECT name="t" id="t">
<OPTION value="at dawn">dawn</OPTION>
<OPTION value="in the morning">morning</OPTION>
<OPTION value="at noon">noon</OPTION>
<OPTION value="in the afternoon">afternoon</OPTION>
<OPTION value="at dusk">dusk</OPTION>
<OPTION value="in the evening">evening</OPTION>
<OPTION value="at night">night</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Vehicle</TD>
<TD>
<SELECT name="veh" id="veh" onChange="idex0(document.frm.veh.options[document.frm.veh.selectedIndex].value); toway();">
<OPTION value="car">car</OPTION>
<OPTION value="taxi">taxi</OPTION>
<OPTION value="4 x 4">4 x 4</OPTION>
<OPTION value="van">van</OPTION>
<OPTION value="bus">bus</OPTION>
<OPTION value="lorry">lorry</OPTION>
<OPTION value="truck">truck</OPTION>
<OPTION value="motor-bike">motor-bike</OPTION>
<OPTION value="bicycle">bicycle</OPTION>
<OPTION value="MPV">MPV</OPTION>
<OPTION value="mini-bus">mini-bus</OPTION>
<OPTION value="smart-car">smart-car</OPTION>
<OPTION value="saloon">saloon</OPTION>
<OPTION value="hatch-back">hatch-back</OPTION>
<OPTION value="estate">estate</OPTION>
<OPTION value="jeep">jeep</OPTION>
<OPTION value="SUV">SUV</OPTION>
<OPTION value="on foot">on foot</OPTION>
<OPTION value="____">other</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Seated at</TD>
<TD>
<SELECT name="loc" id="loc">
<OPTION value="driver">driver</OPTION>
<OPTION value="front-passenger">front-passenger</OPTION>
<OPTION value="rear-passenger">rear-passenger</OPTION>
<OPTION value="rear-passenger (child seat)">rear-passenger (child seat)</OPTION>
<OPTION value="rear-passenger (booster seat)">rear-passenger (booster seat)</OPTION>
<OPTION value="passenger">passenger</OPTION>
<OPTION value="rider">rider</OPTION>
<OPTION value="pillion">pillion</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Accident with</TD>
<TD>
<SELECT name="aw" id="aw">
<OPTION value="a car">car</OPTION>
<OPTION value="a taxi">taxi</OPTION>
<OPTION value="a 4 x 4">4 x 4</OPTION>
<OPTION value="a van">van</OPTION>
<OPTION value="a bus">bus</OPTION>
<OPTION value="a lorry">lorry</OPTION>
<OPTION value="a truck">truck</OPTION>
<OPTION value="an MPV">MPV</OPTION>
<OPTION value="a mini-bus">mini-bus</OPTION>
<OPTION value="a smart-car">smart-car</OPTION>
<OPTION value="a saloon">saloon</OPTION>
<OPTION value="a hatch-back">hatch-back</OPTION>
<OPTION value="an estate">estate</OPTION>
<OPTION value="a jeep">jeep</OPTION>
<OPTION value="an SUV">SUV</OPTION>
<OPTION value="an ambulance">ambulance</OPTION>
<OPTION value="an tractor">tractor</OPTION>
<OPTION value="a motor-bike">motor-bike</OPTION>
<OPTION value="a bicycle">bicycle</OPTION>
<OPTION value="an electric-pole">electric-pole</OPTION>
<OPTION value="a barrier">barrier</OPTION>
<OPTION value="a barrier and spun around">barrier and spun around</OPTION>
<OPTION value="pedestrian">pedestrian</OPTION>
<OPTION value="____">other</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Seat-Belt</TD>
<TD>
<SELECT name="sb" id="sb">
<OPTION value="was not">no</OPTION>
<OPTION value="was" selected="selected">yes</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Head Restraint</TD>
<TD>
<SELECT name="hr" id="hr">
<OPTION value="was not">no</OPTION>
<OPTION value="was" selected="selected">yes</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Air Bag</TD>
<TD>
<SELECT name="ab" id="ab">
<OPTION value="was not" >no</OPTION>
<OPTION value="was" selected="selected">yes</OPTION>
</SELECT>
<SELECT name="abd" id="abd">
<OPTION value="deployed">deploy</OPTION>
<OPTION value="did not deploy" selected="selected">not deployed</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Location</TD>
<TD>
<SELECT name="locat" id="locat" onChange="toway();">
<OPTION value="on a main road">main road</OPTION>
<OPTION value="on a motor way">motor way</OPTION>
<OPTION value="at a set of traffic lights">traffic light</OPTION>
<OPTION value="in a residential street">residential street</OPTION>
<OPTION value="in a car park">car park</OPTION>
<OPTION value="on a side road">side road</OPTION>
<OPTION value="at a junction">junction</OPTION>
<OPTION value="at a round-about">round-about</OPTION>
<OPTION value="in a country lane">country lane</OPTION>
<OPTION value="on a motorway slip-road">motorway slip-road</OPTION>
<OPTION value="on a mincunian way">mincunian way</OPTION>
<OPTION value="at a pelican crossing">pelican crossing</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>State</TD>
<TD>
<SELECT name="stat" id="stat" onChange="toway();">
<OPTION value="stationary">stationary</OPTION>
<OPTION value="moving">moving</OPTION>
<OPTION value="parked">parked</OPTION>
<option value="braking">braking</option>
</SELECT>

<select id="stat2" name="stat2">
</select>
</TD>
</TR>

<TR>
<TD>Collided/Struck</TD>
<TD>
<SELECT name="cost" id="cost">
<OPTION value="collided with">collided</OPTION>
<OPTION value="was struck by" selected="selected">struck</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Impact</TD>
<TD>
<SELECT name="impact" id="impact">
<OPTION value="front">front</OPTION>
<OPTION value="rear" selected="selected">rear</OPTION>
<OPTION value="passenger's side">passenger's side</OPTION>
<OPTION value="driver's side">driver's side</OPTION>
<OPTION value="not known">not known</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Thrown</TD>
<TD>
<SELECT name="thr" id="thr">
<OPTION value="sideways">sideways</OPTION>
<OPTION value="forward then backward" selected="selected">forward then backward</OPTION>
<OPTION value="backward then forward">backward then forward</OPTION>
<OPTION value="in all directions">In All Directions</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Damage</TD>
<TD>
<SELECT name="dam" id="dam">
<OPTION value="write-off">write-off</OPTION>
<OPTION value="cause extensive damage to">extensive</OPTION>
<OPTION value="cause moderate damage to">moderate</OPTION>
<OPTION value="cause minor damage to">minor</OPTION>
<OPTION value="unknown">unknown</OPTION>
</SELECT>
</TD>
</TR>

<TR>
<TD>Speed</TD>
<TD>
<SELECT name="spe" id="spe">
	<OPTION value="">Unknown</OPTION>
	<OPTION value="10 mph">10 mph</OPTION>
	<OPTION value="20 mph">20 mph</OPTION>
	<OPTION value="30 mph">30 mph</OPTION>
	<OPTION value="40 mph">40 mph</OPTION>
	<OPTION value="50 mph">50 mph</OPTION>
	<OPTION value="60 mph">60 mph</OPTION>
	<OPTION value="70 mph">70 mph</OPTION>
	<OPTION value="low speed">Low Speed</OPTION>
	<OPTION value="High speed">High Speed</OPTION>
	<OPTION value="Very High speed">Very High Speed</OPTION>
</TD>
</TR>

<tr>
<TD>Got off/Got Up</TD>
<TD>
<SELECT name="gc" id="gc">
	<option value="">---</option>
	<OPTION value="got out of the vehicle unaided.">unaided</OPTION>
	<OPTION value="needed help to get out of the vehicle.">needed help</OPTION>
</SELECT>
</TD></tr>

<tr>
<td>Visibility</td>
<td>
	<select id="vis">
    	<option value="">---</option>
    	<option value="very low">very low</option>
        <option value="low">low</option>
        <option value="normal">normal</option>
	</select>
</td>
</tr>

<tr>
<td>Weather Conditions</td>
<td>
	<select id="wcond">
    	<option value="">---</option>
    	<option value="sunny">sunny</option>
        <option value="dark">dark</option>
        <option value="cloudless">cloudless</option>
        <option value="cloudy">cloudy</option>
        <option value="drizzling">drizzle</option>
        <option value="raining">rainy</option>
        <option value="foggy with surface spray">foggy</option>
        <option value="foggy with surface spray">foggy with surface spray</option>
        <option value="raining with surface spary">rain with surface spary</option>
        <option value="drizzling with surface spray">drizzling with surface spray</option>
        <option value="cloudy with surface spray">cloudy with surface spray</option>
        <option value="sunny with surface spray">sunny with surface spray</option>
	</select>
</td>
</tr>

<tr>
<td align="center" colspan="2"><select id="sentence">
									<option value="1">As Paragraph</option>
                                    <option value="2">As Points</option>
                                    <option value="3">As Headings</option>
								</select>
</td>
</tr>

<TR><TD align="center" colspan="2"><INPUT type="button" value="Add" onClick="format();"></TD></TR>

<TR><TD colspan="2" align="center"><div align="left" id="accident" style="height:150px; width:90%; border-color:#666; border-width:1px; border-style:inset; overflow:auto;" ><? echo $ra['accid']; ?></div></TD></TR>

<textarea name="accident2" id="accident2" rows="0" cols="0" style="height:0px; width:0px;" ></textarea>

<TR><TD align="center" colspan="2"><INPUT type="button" onClick="submiter();" value="Submit" /></TD></TR>

</TABLE>



</FORM>

<script type="text/javascript" language="javascript">

document.getElementById('accident').contentEditable='true';

</script>

</BODY>
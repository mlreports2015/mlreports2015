<?

require_once( 'DB.php');
$db = DB::connect( "mysql://root:phantom@localhost/wap" );

?>
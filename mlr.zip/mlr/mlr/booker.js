// JavaScript Document

function booker()
{
var url="texter.php";
var aNamer=document.getElementById('aNameI').value;
aName=aNamer.replace(' ', '+');
url=url+"?nums="+nums+'&dt='+document.getElementById('doe').value+'&tm='+document.getElementById('tm').value+'&cid='+document.getElementById('cNameH').value+'&aName='+aName;
}
<?php

session_start();

include "inc.php";


if (!isset($_SESSION['id']))
{
	rdrctr("Login Details Incorrect","index.html");
}
else
{
	include 'dcon.php';
?>
<HEAD>
<TITLE>MLR Case</TITLE>

<SCRIPT language='JavaScript' type='text/javascript' src='Scripts/index.js'></SCRIPT>

<script language="JavaScript" type="text/javascript">
function chnge(a)
{
	var b=document.getElementById(a);
	if (b.checked==true)
	{
		var c=document.getElementById(a+'x');
		c.value=a;
	}
	else
	{
		var c=document.getElementById(a+'x');
		c.value='';
	}
}

function hlp()
{
	document.getElementById('hlpp').style.visibility='visible';
}

function hlpg()
{
	document.getElementById('hlpp').style.visibility='hidden';
}
</script>

<link href="CSS/calender.css" rel="stylesheet" type="text/css">
<script language="javaScript" type="text/javascript" src="Scripts/calender_date_picker.js"></script>

<?
echo "<link href=\"CSS/pmh.css\" rel=\"stylesheet\" type=\"text/css\">
	<script language=\"javaScript\" type=\"text/javascript\" src=\"Scripts/summary.js\"></script>
	<link href=\"CSS/calender.css\" rel=\"stylesheet\" type=\"text/css\">
	<script language=\"javaScript\" type=\"text/javascript\" src=\"Scripts/calender_date_picker.js\"></script>";
?>

</HEAD>

<BODY background="images/back.png">

<? $id= $_GET['cid']; ?>

<DIV style="background-image : url('images/fe.png'); background-repeat : no-repeat; width:1024px; float:right;">
<IMG align="middle" src="images/title3.png" />
<IMG align="middle" src="images/rep.png" style="margin-left : 700px;" />
</DIV>

<DIV style="float:right;right:20px;width:100%;">
<A href=home.php>Home</A> |
<A href=admin.php>Add Case</A> |
<A href=search.php>General Search</A> |
<A href=incomplete.php>Incomplete Cases</A> |
<A href=complete.php>Complete Cases</A> |
 &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; 
<A href=logout.php>Log Out</A> |
</DIV>


<br />
<br />
<br />
<br />
<br />
<br />

<CENTER><H1><? echo "ML".$id;?></H1></CENTER>

<CENTER>
<DIV align="center">

<A href="det.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Details</A> | 

<A href="pmh.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">PMH</A> | 

<A href="accid.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Accident</A> | 

<A href="effect.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Symptoms</A> | 

<A href="treat.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Treatment</A> | 

<A href="life.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Life</A> | 

<A href="exam.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>"> Examination </A> | 

<A href="summary.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Summary</A> | 

<A href="prog.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Prognosis </A> | 

<A href="repgen.php?cid=<? echo $id; ?>&id=<? echo rand(0,1000); ?>">Report</A> | 

<Div style="width:100%"></DIV>
</DIV>
</CENTER>



<FORM method="POST" action="Process/repgen.php">
<input type="hidden" value="" name="p1x" id="p1x"/>
<h4><center>Optional Referrances<a onMouseOver="hlp();" onMouseOut="hlpg();"><img src="images/help.png"/></a></center></h4>
<p style="background-color:#fff;"><input value="p1" type="checkbox" id="p1" name="p1" onClick="chnge('p1');" />Studies have shown that the rate of recovery of a soft tissue injury to the cervical, thoracic and lumbar spine resulting in a whiplash injury without nerve route compression or bony injury following a road traffic accident is variable. Whiplash injury is defined as a traumatic injury to the soft tissue structures of the cervical spine including muscles, ligaments, intervertebral discs and facet joints due to hyper flexion and hyper extension, rotational injury and transmitted impact from the seat belt.</p>
<input type="hidden" value="" name="p2x" id="p2x"/>
<p style="background-color:#fff;"><input value="p2" type="checkbox" id="p2" name="p2" onClick="chnge('p2');" />The range of recovery varies from few months of the accident to subjects being left with long term spinal symptoms. Analysis of studies shows that a significant number of subjects sustaining spinal injuries in road traffic accidents will continue to suffer cervical spine pain at 3 years post accident. There is a large body of medical literature both from the United Kingdom and other countries regarding neck injuries and road traffic accidents. Review of the medical literature reveals variation in various prognostic factors for recovery from whiplash injury.</p>



<input type="hidden" value="<? $id= $_GET['cid']; echo $id;?>" name="id" />

<DIV align="center" style="padding-top : 50pxpx;">
<INPUT type="submit" value="Generate Report" />
</DIV>

</FORM>

<FORM method="POST" action="Process/repinv.php">
<input type="hidden" value="<? $id= $_GET['cid']; echo $id;?>" name="id" />

<DIV align="center" style="padding-top : 50pxpx;">
Charges &#163;<input type="text" name="chrge" size=1 />
<br />
<INPUT type="submit" value="Generate Invoice with VAT" />
</DIV>

<!-- <TEXTAREA id='ta' title=xyz>a  x </TEXTAREA> -->

</FORM>


<FORM method="POST" action="Process/repinvx.php">
<input type="hidden" value="<? $id= $_GET['cid']; echo $id;?>" name="idx" />

<DIV align="center" style="padding-top : 50pxpx;">
Charges &#163;<input type="text" name="chrgex" size=1 />
<br />
<INPUT type="submit" value="Generate Invoice with without VAT" />
</DIV>

<!-- <TEXTAREA id='ta' title=xyz>a  x </TEXTAREA> -->
</FORM>

<center>
<?php
$s="select * from claimant where cid='$id' and stat='c'";
// echo $s;
$q=mysql_query($s);
$r=mysql_num_rows($q);

if ($r>0)
{
?>

<form action="icomp.php" method="POST">
	<input type="hidden" name="id" value="<?php echo $id;?>" />
	<input type="submit" value="Mark Incomplete" />
</form>

<?php
}
else
{
?>
<form action="comp.php" method="POST">
	<input type="hidden" name="id" value="<?php echo $id;?>" />
	<input type="submit" value="Mark Complete" />
</form>
<?php
}
?>
</center>


<div style="background-color:#FFFBB4; visibility:hidden; position:absolute;top:250px;left:215px;width:500px;" id="hlpp">Optional references that can be added to the report. Click the check-box if you want to add that reference to the prognosis section of the report.</div>

</BODY>

</HTML>
<?
}?>